/*
 * 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
 * 𝘵𝘦𝘭𝘦: https://t.me/owenssw
 * 𝘪𝘯𝘧𝘰: https://s.id/26AYH
 * 𝘺𝘵: https://youtube.com/CekGem
 * 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

function _0x552e() {
    const _0x289e4f = ['Restarting Bot...', '432460fPiMmV', '1779633fzuCBk', '27WfRfap', 'ipc', 'path', 'argv', 'child_process', '3610160uNAcbC', '584801rNkbIS', '12XXCaRq', '16HYYcKk', 'log', '463xrauFC', '42RwUaik', '7760580LfIAfi', '1336654NsUeuB', 'servers/index.js', 'Exited with code:', 'reset', 'inherit', 'kill', 'message', 'slice', '1256BiSwAE', 'exit'];
    _0x552e = function () {
        return _0x289e4f;
    };
    return _0x552e();
}
const _0xfd279c = _0x5adb;

function _0x5adb(_0xed8d58, _0x129abc) {
    const _0x552eb0 = _0x552e();
    return _0x5adb = function (_0x5adbe8, _0x4b1609) {
        _0x5adbe8 = _0x5adbe8 - 0x86;
        let _0x2ed1d5 = _0x552eb0[_0x5adbe8];
        return _0x2ed1d5;
    }, _0x5adb(_0xed8d58, _0x129abc);
}(function (_0x4c3804, _0xa2c9be) {
    const _0xed481e = _0x5adb,
        _0x2c7d53 = _0x4c3804();
    while (!![]) {
        try {
            const _0xed1d96 = -parseInt(_0xed481e(0x8c)) / 0x1 * (parseInt(_0xed481e(0x97)) / 0x2) + -parseInt(_0xed481e(0x9b)) / 0x3 + -parseInt(_0xed481e(0x8a)) / 0x4 * (-parseInt(_0xed481e(0x9a)) / 0x5) + parseInt(_0xed481e(0x8d)) / 0x6 * (parseInt(_0xed481e(0x88)) / 0x7) + parseInt(_0xed481e(0x87)) / 0x8 * (parseInt(_0xed481e(0x9c)) / 0x9) + -parseInt(_0xed481e(0x8e)) / 0xa + parseInt(_0xed481e(0x8f)) / 0xb * (parseInt(_0xed481e(0x89)) / 0xc);
            if (_0xed1d96 === _0xa2c9be) break;
            else _0x2c7d53['push'](_0x2c7d53['shift']());
        } catch (_0x13fd5b) {
            _0x2c7d53['push'](_0x2c7d53['shift']());
        }
    }
}(_0x552e, 0xb624c));
const {
    spawn
} = require(_0xfd279c(0x86)), path = require(_0xfd279c(0x9e));

function start() {
    const _0x2c44a5 = _0xfd279c;
    let _0x31a0c1 = [path['join'](__dirname, _0x2c44a5(0x90)), ...process[_0x2c44a5(0x9f)][_0x2c44a5(0x96)](0x2)];
    console[_0x2c44a5(0x8b)]([process[_0x2c44a5(0x9f)][0x0], ..._0x31a0c1]['join']('\x0a'));
    let _0x38da34 = spawn(process['argv'][0x0], _0x31a0c1, {
        'stdio': [_0x2c44a5(0x93), _0x2c44a5(0x93), 'inherit', _0x2c44a5(0x9d)]
    })['on'](_0x2c44a5(0x95), _0x53c70b => {
        const _0x49d219 = _0x2c44a5;
        _0x53c70b == _0x49d219(0x92) && (console[_0x49d219(0x8b)](_0x49d219(0x99)), _0x38da34[_0x49d219(0x94)](), start(), delete _0x38da34);
    })['on'](_0x2c44a5(0x98), _0x34b2c0 => {
        const _0x3ff859 = _0x2c44a5;
        console['error'](_0x3ff859(0x91), _0x34b2c0);
        if (_0x34b2c0 == '.' || _0x34b2c0 == 0x1 || _0x34b2c0 == 0x0) start();
    });
}
start();